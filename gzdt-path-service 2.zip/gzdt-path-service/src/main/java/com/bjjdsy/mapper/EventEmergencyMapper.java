package com.bjjdsy.mapper;

import com.bjjdsy.pojo.EventEmergency;

public interface EventEmergencyMapper {
    EventEmergency findByRecordId(Integer record_id);
}
