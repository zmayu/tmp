package com.bjjdsy.mapper;

public interface ParamLineMapper {
    String findLineColor(String versionCode, String lineName);
}
