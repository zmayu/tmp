package com.bjjdsy.mapper;

import com.bjjdsy.pojo.BasePassFavLevel;

public interface BasePassFavLevelMapper {

    BasePassFavLevel findPassFavLevel(String userId);
}
