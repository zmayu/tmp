package com.bjjdsy.mapper;


import java.util.Date;
import java.util.List;

public interface ParamCalendarMapper {
    //    List<Date> findCalendarDayList(String day_type,String week_day);
    List<Date> findCalendarDayList(Integer day_type, Integer week_day,Date systemDateNow);

}
