package com.bjjdsy.mapper;

import com.bjjdsy.pojo.*;

import java.util.Date;
import java.util.List;

//import com.bjjdsy.pojo.RecommendPath;

public interface gzdt_553Mapper {

    //    List<gzdt_553> findbyOD(String oStationCode, String dStationCode, String dataVersion);
    List<gzdt_553> findbyOD(String oStationCode, String dStationCode, String dataVersion, String user);

    //    List<gzdt_553> findbyODIndex(String oStationCode, String dStationCode, Integer pathIndex, String dataVersion);
    List<gzdt_553> findbyODIndex(String oStationCode, String dStationCode, Integer pathIndex, String dataVersion, String user);

    //    List<gzdt_553> findbyODId(String oStationCode, String dStationCode, String id);
    List<gzdt_553> findbyODId(String oStationCode, String dStationCode, String id, String user);

    List<gzdt_553> findDetailbyId(String id);

    List<BaseOdPathLast> findFinalTime(String oStationCode, String dStationCode, String dataVersion, String pathStations, String user);

    List<BaseOdPathLast> findOdFinalTime(String dataVersion, String oStationCode, String dStationCode);


    List<BaseOdPathLast> findOdPathFinalTime(String dataVersion, String pathStations);

    //    List<gzdt_553> findOdPathBeginTime(String dataVersion,String pathStations);

    //    List<gzdt_553> findStationName(String stationCode, String dataVersion);
    List<gzdt_553> findStationName(String stationCode, String dataVersion, String user);

    //    List<gzdt_553> findDelayByDate(Date departTime);
    //    List<gzdt_553> findDelayByDate(Date departTime,String user);

    //    List<EventInfluenceData> findDelayByDate(Date departTime, String user);

    List<EventInfluenceData> findDelayByDate(Date departTime, String user, Date systemDateNow);

    List<gzdt_553> findFavById(String userId);

    //    List<gzdt_553> findNormalLimitByOTime(String oStationCode, String departTime, String dataVersion);
    List<gzdt_553> findNormalLimitByOTime(String oStationCode, String departTime, String dataVersion, String user);

    //    List<gzdt_553> findChaRateByDayTypeWeekDay(String oStationCode, String dStationCode, Integer day_type, Integer week_day, String shike, String dataVersion);
    List<gzdt_553> findChaRateByDayTypeWeekDay(String oStationCode, String dStationCode, Integer day_type, Integer week_day, String shike, String dataVersion, String user);

    List<gzdt_553> findHisRateByDate(String oStationCode, String dStationCode, String shike, String calendar_day, String user);

    //    gzdt_553 findDataTypeWeekDay(Date calendar_day);
    gzdt_553 findDataTypeWeekDay(Date calendar_day, String user);

    String findDataType(Date calendar_day, String user);

    //    gzdt_553 findOdLastVersion(Date calendar_day);
    gzdt_553 findOdLastVersion(Date calendar_day, String user);

    gzdt_553 findDataVersion(String param_code);

    //    gzdt_553 findSectionDStationCode(String oStationCode, String up_down, String version_code);
    gzdt_553 findSectionDStationCode(String oStationCode, String up_down, String version_code, String user);

    ParamSection findSectionMessageByOD(String oStationCode, String dStationCode, String version_code, String user);

    ParamSection findSectionMessageByODirection(String oStationCode, String up_down, String version_code);

    ParamSection findSectionMessageByODirectionLineAfc(String oStationCode, String up_down, String version_code, String line_afc_code);

    //    String findTimeTableVersion(Date calendar_day);
    String findTimeTableVersion(Date calendar_day, String user);

    //    String findAverageWaitTime(String oStationCode, String dStationCode, String hour, String dataVersion);
    String findAverageWaitTime(String oStationCode, String dStationCode, String hour, String dataVersion, String user);

    //    List<String> findODAverageWaitTime(String oStationCode, String dStationCode, String dataVersion);
    List<String> findODAverageWaitTime(String dataVersion);

    //    PassFavCoefficient findFavCoefficient(String userId);
    PassFavCoefficient findFavCoefficient(String userId);

    //    String findLineName(String versionCode, String lineAfcCode);
    String findLineName(String versionCode, String lineAfcCode, String user);

    //    String findLineEnName(String versionCode, String lineName);
    String findLineEnName(String versionCode, String lineName, String user);

    //    String findStationEnName(String versionCode,String stationCode);
    String findStationEnName(String versionCode, String stationCode, String lineAfcCode);
    //    String findStationEnName(String versionCode, String stationCode, String lineAfcCode,String user);

    List<String> findStationCode(String versionCode, String stationName,String user);


    List<ParamLoadRate> findParamLoadRate();

}
