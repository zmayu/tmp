package com.bjjdsy.mapper;

public interface ManageTimeThresholdMapper {
    Integer findTimeThresholdByType();
}
