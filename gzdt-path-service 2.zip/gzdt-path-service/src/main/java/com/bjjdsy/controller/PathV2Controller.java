package com.bjjdsy.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.bjjdsy.entity.*;
import com.bjjdsy.pojo.*;
import com.bjjdsy.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Collections.max;
import static java.util.Collections.min;

@RestController
@CrossOrigin
public class PathV2Controller {
    static String param_code = "VER_OD_PATH";
    Logger logger = LoggerFactory.getLogger(PathV2Controller.class);

    @Resource
    private Gzdt_553Service gzdt_553;
    @Resource
    private BasePassFavLevelService basePassFavLevelService;
    @Resource
    private ParamLineService paramLineService;
    @Resource
    private ParamCalendarService paramCalendarService;
    @Resource
    private EventEmergencyService eventEmergencyService;

    @Resource
    private ManageTimeThresholdService manageTimeThresholdService;


    /**
     * 检查当前出发时间是否小于凌晨4点，如果小于则LastAndWaitDate 则末班车和时刻表需要前一天的数据
     *
     * @param departTimeGet
     * @return
     */
    public Date checkNeedBeforeDate(String departTimeGet) throws ParseException {
        boolean ifNeedBeforeDate = false;
        Date lastAndWaitDate = null;
        //凌晨4点
        //todo mapper.xml中的sql和数据库里的对应不上，该方法不重要暂时先注视
        Integer timeThreshold = null;// = manageTimeThresholdService.findTimeThresholdByType();
        if (timeThreshold == null) {
            timeThreshold = 4;
        }
        if (Integer.valueOf(departTimeGet.substring(8, 10)) < timeThreshold) {
            logger.info("末班车和时刻表需要用前一天的数据");
            lastAndWaitDate = DateMinus1(getDateTime(departTimeGet), "yyyy-MM-dd HH:mm:ss", -1);
        } else {
            logger.info("末班车和时刻表需要用当天的数据");
            lastAndWaitDate = getDateTime(departTimeGet);
        }
        return lastAndWaitDate;
    }

    /**
     * 为OD Path设置末班车时间提示
     *
     * @param gzdt_5531
     * @param oStationCode
     * @param dStationCode
     * @param MBCdataVersion
     * @param pathStations
     */
    public void setODPathLastTrainTime(com.bjjdsy.pojo.gzdt_553 gzdt_5531, String oStationCode, String dStationCode, String MBCdataVersion, String pathStations) {
        String beginTime = "06:00:00";
        String lastTime = "23:59:59";
        List<BaseOdPathLast> odPathLasts = gzdt_553.findFinalTime(oStationCode, dStationCode, MBCdataVersion, pathStations, "user");
        if (odPathLasts.size() != 0) {
            beginTime = odPathLasts.get(0).getBegin_time();
            lastTime = odPathLasts.get(0).getLast_time();
            logger.info("lastTime:" + lastTime);
            //路径末班车，本路线末班车时刻为XX:XX，请提前5分钟以上进站乘车
            //The last bus of this route is at 23:23, please get in at least 5 minutes in advance and board the bus
            //The last train of this route arrives at 23:23, please enter the station more than 5 minutes in advance
            gzdt_5531.setPathLastTime("本路线末班车时刻为" + lastTime.substring(0, 5) + "，请提前5分钟以上进站乘车");
            gzdt_5531.setEnPathLastTime("The last train of this route arrives at " + lastTime.substring(0, 5) + ", please enter the station at least 5 minutes in advance");
        } else {
            logger.info("没有最邻近和默认末班车数据");
            //路径末班车
            gzdt_5531.setPathLastTime("");
            gzdt_5531.setEnPathLastTime("");
        }
        gzdt_5531.setBegin_time(beginTime);
        gzdt_5531.setLast_time(lastTime);
    }

    /**
     * 检查出行时间是否在营用时间内
     *
     * @param gzdt_5531
     * @param lastAndWaitDate
     * @param departTimeGet
     * @param departTimeHMS
     * @return
     * @throws ParseException
     */
    public boolean checkDepartTimeWithInCampTime(com.bjjdsy.pojo.gzdt_553 gzdt_5531, Date lastAndWaitDate, String departTimeGet, String departTimeHMS) throws ParseException {
        boolean isWithInCampTime = false;
        //末班车的时刻
        if (getFormatDate(gzdt_5531.getLast_time(), "HH:mm:ss").getTime() < getFormatDate(gzdt_5531.getBegin_time(), "HH:mm:ss").getTime()) {
            logger.info("末班车时间<首班车时间，说明末班车时间在0点之后");
            String beginTime = getDataToFormatString(lastAndWaitDate, "yyyyMMdd").substring(0, 8) + gzdt_5531.getBegin_time();
            String lastTime = getDataToFormatString(DateMinus1(lastAndWaitDate, "yyyyMMdd", 1), "yyyyMMdd").substring(0, 8) + gzdt_5531.getLast_time();
            if ((getFormatDate(lastTime, "yyyyMMddHH:mm:ss").getTime() > getFormatDate(departTimeGet, "yyyyMMddHHmmss").getTime()) && (getFormatDate(departTimeGet, "yyyyMMddHHmmss").getTime() > getFormatDate(beginTime, "yyyyMMddHH:mm:ss").getTime())) {
                logger.info("出行时间在首末班车之间");
                isWithInCampTime = true;
            } else {
                logger.info("出行时间不在运营时间范围内，早于或晚于首班车");
            }
        } else {
            logger.info("末班车时间在0点之前");
            if ((getFormatDate(gzdt_5531.getBegin_time(), "HH:mm:ss").getTime() < getFormatDate(departTimeHMS, "HH:mm:ss").getTime()) && (getFormatDate(departTimeHMS, "HH:mm:ss").getTime() < getFormatDate(gzdt_5531.getLast_time(), "HH:mm:ss").getTime())) {
                logger.info("出发时间在首末班车之间");
                isWithInCampTime = true;
            } else {
                logger.info("出发时间在首末班车之外");
            }
        }
        return isWithInCampTime;
    }

    /**
     *
     * @param oStationCode
     * @param dStationCode
     * @param departTimeGet
     * @param OdPathDataVersion
     * @param lastAndWaitDate
     * @return
     * @throws ParseException
     */
    public List<gzdt_553> calculateODPath(String oStationCode, String dStationCode, String departTimeGet, String OdPathDataVersion, Date lastAndWaitDate) throws ParseException {
        Date systemDateNow = new Date();
        //末班车、时刻表查询版本的日期
        logger.info("LastAndWaitDate:" + lastAndWaitDate);
        //找到有数据的时刻表版本
        String timetableVersion = findTimeTableVersion(lastAndWaitDate);
        //找到有数据的末班车版本
        String MBCdataVersion = findOdPathLastTimeVersion(lastAndWaitDate, oStationCode, dStationCode);
        Date theDayBeforeYesterdayDateNow = DateMinus1(new Date(), "yyyy-MM-dd", -2);
        List<gzdt_553> paths = gzdt_553.findbyOD(oStationCode, dStationCode, OdPathDataVersion, "user");
        List<gzdt_553> oDPathLists = new ArrayList<>();
        //获取突发事件以及常态进站限流对总时间和等待事件的影响
        for (com.bjjdsy.pojo.gzdt_553 gzdt_5531 : paths) {
            //初始化时间
            Date departTime = getDateTime(departTimeGet);
            Integer totalTime = 0;
            Integer totalWaitTime = 0;
            Integer totalWalkTime = 0;
            Date timeNow = departTime;//出发时间初始化
            String departTimeHMS = getDataToFormatString(departTime, "HH:mm:ss");
            String recordId = Integer.toString(gzdt_5531.getRecord_id());
            String pathStations = gzdt_5531.getPath_stations();
            //为OD路径设置末班车时间
            setODPathLastTrainTime(gzdt_5531, oStationCode, dStationCode, MBCdataVersion, pathStations);
            //检查出行时间是否在OD路径的营用时间内
            boolean isWithInCampTime = checkDepartTimeWithInCampTime(gzdt_5531, lastAndWaitDate, departTimeGet, departTimeHMS);
            if (isWithInCampTime) {
                gzdt_553 gzdt553 = calculatePathParam(pathStations, oStationCode, dStationCode, recordId, timeNow, theDayBeforeYesterdayDateNow, departTime, gzdt_5531, totalTime, totalWaitTime, totalWalkTime, systemDateNow, timetableVersion);
                if(!Objects.isNull(gzdt553)){
                    oDPathLists.add(gzdt553);
                }
            }
        }
        return oDPathLists;
    }

    /**
     *   为odpath计算路径的各参数
     *   1. loadsByLine 线路的满载率
     *   2. totalTime  总旅行时间
     *   3. totalWaitTime 总的等待时间
     *   4. totalWalkTime 总的步行时间
     *   5. linesColor 各线路中文颜色
     *   6. enLinesColor  各线路英文颜色
     *   7. chinesePathName 各线路中文名称
     *   8. Influence 线路是否受突发时间影响
     *
     * @param path_station                 "0101-0102-0103-0201"
     * @param oStationCode
     * @param dStationCode
     * @param strid
     * @param timeNow
     * @param theDayBeforeYesterdayDateNow
     * @param departTime
     * @param gzdt_5531
     * @param totalTime
     * @param totalWaitTime
     * @param totalWalkTime
     * @param systemDateNow
     * @param timetableVersion
     * @throws ParseException 计算OD-path
     */
    public gzdt_553 calculatePathParam(String path_station, String oStationCode, String dStationCode, String strid, Date timeNow, Date theDayBeforeYesterdayDateNow, Date departTime, gzdt_553 gzdt_5531, Integer totalTime, Integer totalWaitTime, Integer totalWalkTime, Date systemDateNow, String timetableVersion) throws ParseException {
        //拆出路径中所有车站
        String[] sArray = path_station.split("-");
        List<String> stationList = Arrays.asList(sArray);
        List<String> rateLineNameList = new ArrayList<>();

        param_code = "VER_NET_PARAM";
        gzdt_553 netVersion = gzdt_553.findDataVersion(param_code);
        if (netVersion != null) {
            String netDataVersion = netVersion.getParam_value();
            String OtransStationCode = oStationCode;
            String DtransStationCode = dStationCode;

            //判断o站/d站是否是换乘站
            if (gzdt_553.findStationName(stationList.get(0), netDataVersion, "user").size() != 0) {
                deleteRepetitiveStationResult deleteResult = deleteRepetitiveStation(stationList, netDataVersion, oStationCode, OtransStationCode, dStationCode, DtransStationCode);
                oStationCode = deleteResult.getoStationCode();
                OtransStationCode = deleteResult.getOtransStationCode();
                dStationCode = deleteResult.getdStationCode();
                DtransStationCode = deleteResult.getDtransStationCode();
                //区间上下行方向
                String overrun_up_down = "";
                //换乘站和前一站区间上下行方向
                String overrun_beforeOs_transStationCode = "";
                //路径满载率集合
                MultiValueMap<String, Double> loadsByLine = new LinkedMultiValueMap<>();
                logger.info("odpathDetail-start");
                List<gzdt_553> OdpathDetail = gzdt_553.findDetailbyId(strid);
                logger.info("odpathDetail-end");
                if (OdpathDetail.size() != 0) {
                    //解析每个站的信息
                    for (gzdt_553 stationDetail : OdpathDetail) {
                        String oS = stationDetail.getO_station_code_detail();
                        String oD = stationDetail.getD_station_code_detail();
                        //区间上下行
                        ParamSection paramSection = gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user");
                        if (paramSection != null) {
                            overrun_up_down = paramSection.getUp_down();
                        }
                        String beforeOs = "";
                        Integer waitTime = 0;
                        String transStationCode = stationDetail.getTrans_station_code();
                        String transLineAfcCode = stationDetail.getTrans_line_afc_code();
                        String lineAfcCode = stationDetail.getLine_afc_code();

                        if (transStationCode != null) {
                            beforeOs = OdpathDetail.get(stationDetail.getPath_station_index() - 2).getO_station_code_detail();
                            overrun_beforeOs_transStationCode = gzdt_553.findSectionMessageByOD(beforeOs, transStationCode, netDataVersion, "user").getUp_down();
                        }
                        //进站的等待时间（第一站和换乘站是需要等待列车到达）
                        if (stationDetail.getPath_station_index() == 1) {
                            waitTime = findWaitTime(timeNow, oS, oD, waitTime, stationDetail, timetableVersion);
                        } else {
                            if (transStationCode != null) {
                                waitTime = findWaitTime(timeNow, oS, oD, waitTime, stationDetail, timetableVersion);
                            }
                        }
                        //列车站点间的运行时间
                        Integer travelTime = stationDetail.getTravel_time();
                        //不同线路的换乘时间
                        Integer transTime = stationDetail.getTrans_time();
                        //获取满载率
                        String shike = getDataToFormatString(timeNow, "HH:mm:ss");
                        String HHmm = getDataToFormatString(timeNow, "HH:mm");
                        List<gzdt_553> fullLoadRate = new ArrayList<>();
                        //T-2
                        if (stationDetail.getPath_station_index() != OdpathDetail.size()) {
                            if (theDayBeforeYesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {
                                logger.info("T-2及以前，使用历史满载率");
                                //查找历史满载率
                                fullLoadRate = getHisLoadRate(oS, oD, departTime, HHmm, shike);
                            } else {
                                //查找特征满载率
                                fullLoadRate = getLoadRate(oS, oD, departTime, shike);
                            }
                        } else {
                            logger.info("最后一个区间，oS为d");
                        }
                        //运行线路名称
                        String lineName = gzdt_553.findLineName(netDataVersion, stationDetail.getLine_afc_code(), "user");
                        rateLineNameList.add(lineName == null ? "" : lineName);
                        if (fullLoadRate.size() != 0) {
                            loadsByLine.add(lineName, fullLoadRate.get(0).getLoad_rate());
                        } else {
                            loadsByLine.add(lineName, 0.0);
                        }
                        EventInfluence eventInfluence = getEventInfluence(timeNow, transStationCode, gzdt_5531, oStationCode, dStationCode, oD, oS, OtransStationCode, DtransStationCode, beforeOs, overrun_up_down, overrun_beforeOs_transStationCode, systemDateNow, transLineAfcCode, lineAfcCode);
                        gzdt_5531.setInfluence(gzdt_5531.isSectionEventInfluence());

                        //区间运行时间
                        timeNow.setTime(timeNow.getTime() + (travelTime + waitTime + transTime) * 1000);
                        totalTime = totalTime + travelTime + waitTime + transTime;
                        totalWaitTime = totalWaitTime + waitTime;
                        totalWalkTime += transTime;
                    }
                } else {
                    logger.info(strid + "：base_od_path_detail表中缺少" + strid + "对应的数据");
                }
                gzdt_5531.setTotal_time(totalTime);// 更新总旅行时间
                gzdt_5531.setWait_time(totalWaitTime);// 计算等待时间
                gzdt_5531.setTotalWalkTime(totalWalkTime);// 计算走行时间
                //获得路径中各线路最大满载率
                findMaxLoadByLine(loadsByLine, gzdt_5531);
                //处理pathName和线路颜色 0101(01)-0102(01)-0103(01)-0201(02
                String[] pathName = gzdt_5531.getPath_name().split("\\(|-|\\)");
                List<String> pathNameList = new ArrayList<>();
                List<String> lineNameList = new ArrayList<>();
                Map<String, String> linesColor = new LinkedHashMap();
                Map<String, String> enLinesColor = new LinkedHashMap();
                StringBuilder stringBuilder = new StringBuilder();
                for (String pathNa : pathName) {
                    if (pathNa.length() != 0) {
                        pathNameList.add(pathNa);
                    }
                }
                for (int i = 0; i < pathNameList.size(); i++) {
                    if (i % 2 == 0) {
                        String pathStationName = gzdt_553.findStationName(pathNameList.get(i), netDataVersion, "user").get(0).getStation_name();
                        stringBuilder.append(pathStationName);
                    } else {
                        String pathLineName = gzdt_553.findLineName(netDataVersion, pathNameList.get(i), "user");
                        lineNameList.add(pathLineName);
                        stringBuilder.append("(" + pathLineName + ")-");

                        String lineColor = paramLineService.findLineColor(netDataVersion, pathLineName);
                        String enLineName = gzdt_553.findLineEnName(netDataVersion, pathLineName, "user");

                        linesColor.put(pathLineName, lineColor);
                        enLinesColor.put(enLineName, lineColor);
                    }
                }

                gzdt_5531.setLinesColor(linesColor);
                gzdt_5531.setEnLinesColor(enLinesColor);
                gzdt_5531.setChinesePathName(stringBuilder.toString());

            }
        } else {
            logger.info("param_station缺少当前net的版本号对应的数据");
            gzdt_5531 = null;
        }
        return gzdt_5531;

    }


    /**
     * 构建OD路径响应对象 OdPathResponseData
     *
     * @param basePassFavLevel
     * @param finalPaths
     * @param oStationCode
     * @param dStationCode
     * @param departTimeGet
     * @return
     */
    public List<OdPathResponseData> buildOdPathResponseDataList(BasePassFavLevel basePassFavLevel, List<com.bjjdsy.pojo.gzdt_553> finalPaths, String oStationCode, String dStationCode, String departTimeGet) {
        List<OdPathResponseData> odPathResponseDataLists = new ArrayList<>();
        List<OdPathResponseData> eventResponseDataRoutes = new ArrayList<>();
        if (basePassFavLevel != null) {
            for (com.bjjdsy.pojo.gzdt_553 route : finalPaths) {
                String[] types = null;
                OdPathResponseData odPathResponseData = new OdPathResponseData();
                odPathResponseData.setoStationCode(oStationCode);
                odPathResponseData.setdStationCode(dStationCode);
                odPathResponseData.setPathIndex(route.getPath_index());
                odPathResponseData.setPathName(route.getChinesePathName());
                odPathResponseData.setStationAmount(route.getStation_amount());
                odPathResponseData.setTransAmount(route.getTrans_amount());
                odPathResponseData.setTicketPrice(route.getTicket_price());
                odPathResponseData.setTotalTime(route.getTotal_time());
                odPathResponseData.setLoad_rate(route.getLoad_rate());
                //拥挤度颜色
                odPathResponseData.setLoad_rate_color(route.getLoad_rate_color());
                odPathResponseData.setLinesLoadRate(route.getLinesLoadRate());
                //线路拥挤度等级
                odPathResponseData.setLinesLoadLevel(route.getLinesLoadLevel());
                odPathResponseData.setRecoType(route.getRecoType());
                odPathResponseData.setDepartTime(departTimeGet);
                odPathResponseData.setLogitValue(route.getV_logit());
                odPathResponseData.setRecordId(route.getRecord_id());
                odPathResponseData.setLinesColor(route.getLinesColor());
                odPathResponseData.setEnLinesColor(route.getEnLinesColor());
                //路径末班车
                odPathResponseData.setPathLastTime(route.getPathLastTime());
                odPathResponseData.setEnPathLastTime(route.getEnPathLastTime());
                //计算三个偏好对应的数值
                calculatePasLevelValue(basePassFavLevel, route, odPathResponseData);
                //路径标签不为空
                if (!route.getRecoType().equals("")) {
                    types = route.getRecoType().split("-");
                    if (Arrays.asList(types).contains("event")) {
                        logger.info("该路径受突发影响");
                        eventResponseDataRoutes.add(odPathResponseData);
                    } else {
                        odPathResponseDataLists.add(odPathResponseData);
                    }
                } else {
                    logger.info("该路径没有偏好标签");
                    odPathResponseDataLists.add(odPathResponseData);
                }
            }
            //根据偏好等级排序，将除了突发的路径根据偏好排序
            odPathResponseDataLists = sortListByMultPas(odPathResponseDataLists);
            eventResponseDataRoutes = sortListByMultPas(eventResponseDataRoutes);
            //合并
            odPathResponseDataLists.addAll(eventResponseDataRoutes);
        } else {
            //如果没有设置偏好
            logger.info("该乘客没有设置出行偏好");
            for (com.bjjdsy.pojo.gzdt_553 route : finalPaths) {
                String[] types = null;
                OdPathResponseData data = new OdPathResponseData();
                data.setoStationCode(oStationCode);
                data.setdStationCode(dStationCode);
                data.setPathIndex(route.getPath_index());
                data.setPathName(route.getChinesePathName());
                data.setStationAmount(route.getStation_amount());
                data.setTransAmount(route.getTrans_amount());
                data.setTicketPrice(route.getTicket_price());
                data.setTotalTime(route.getTotal_time());
                data.setLoad_rate(route.getLoad_rate());
                //拥挤度颜色
                data.setLoad_rate_color(route.getLoad_rate_color());
                data.setLinesLoadRate(route.getLinesLoadRate());
                //线路拥挤度等级
                data.setLinesLoadLevel(route.getLinesLoadLevel());
                data.setRecoType(route.getRecoType());
                data.setDepartTime(departTimeGet);
                data.setLinesColor(route.getLinesColor());
                data.setEnLinesColor(route.getEnLinesColor());
                data.setLogitValue(route.getV_logit());
                data.setRecordId(route.getRecord_id());
                //路径末班车
                data.setPathLastTime(route.getPathLastTime());
                data.setEnPathLastTime(route.getEnPathLastTime());
                odPathResponseDataLists.add(data);
                //转成json
                sortOdPathResponseDataList(odPathResponseDataLists);
            }
        }
        return odPathResponseDataLists;
    }

    /**
     * 设置login效用值
     *
     * @param gzdt_5532
     * @param passFavCoefficient
     */
    public void setLogit(com.bjjdsy.pojo.gzdt_553 gzdt_5532, PassFavCoefficient passFavCoefficient) {
        if (gzdt_5532.getLoad_rate() == null) {
            //没有满载率数据
            gzdt_5532.setLoad_rate(0.00);
        }
        Integer RunTime = gzdt_5532.getTotal_time() - gzdt_5532.getTotalWalkTime() - gzdt_5532.getWait_time();
        if (passFavCoefficient != null) {
            gzdt_5532.setV_logit(logit(passFavCoefficient.getTrans_coef(), passFavCoefficient.getTrans_count_coef(), passFavCoefficient.getTrafic_jam_one(), passFavCoefficient.getTrafic_jam_two(), RunTime, gzdt_5532.getLoad_rate(), gzdt_5532.getTrans_amount(), gzdt_5532.getWait_time(), gzdt_5532.getTotalWalkTime()));
        } else {
            passFavCoefficient = gzdt_553.findFavCoefficient("default", "user");
            if (passFavCoefficient != null) {
                gzdt_5532.setV_logit(logit(passFavCoefficient.getTrans_coef(), passFavCoefficient.getTrans_count_coef(), passFavCoefficient.getTrafic_jam_one(), passFavCoefficient.getTrafic_jam_two(), RunTime, gzdt_5532.getLoad_rate(), gzdt_5532.getTrans_amount(), gzdt_5532.getWait_time(), gzdt_5532.getTotalWalkTime()));
            } else {
                gzdt_5532.setV_logit(logit(1.535, 0.073, 0.15, 0.2, RunTime, gzdt_5532.getLoad_rate(), gzdt_5532.getTrans_amount(), gzdt_5532.getWait_time(), gzdt_5532.getTotalWalkTime()));
            }
        }
        //突发事件
        if (gzdt_5532.isInfluence() == true) {
            gzdt_5532.setV_logit(gzdt_5532.getV_logit() * 10);
        }
    }


    /**
     * 已完成
     *
     * @param ReqMsg oStationCode, dStationCode x-www-form-urlencoded格式
     * @return OdPathResponseMessage
     */
    @CrossOrigin
    @RequestMapping(value = "/v2/gzdtapp/odpath", method = RequestMethod.POST)
    public OdPathResponseMessage odPath(@RequestBody String ReqMsg) throws ParseException {
       //step1.解析请求参数
        OdPathRequestMessage odPathRequestMessage = JSONObject.parseObject(ReqMsg, OdPathRequestMessage.class);
        List<OdPathResponseData> odPathResponseDataList = new ArrayList<>();
        String oStationCode = odPathRequestMessage.getData().getoStationCode();
        String dStationCode = odPathRequestMessage.getData().getdStationCode();//前端获取数据
        String departTimeGet = odPathRequestMessage.getData().getDepartTime();//前端获取数据
        String userId = odPathRequestMessage.getData().getUserId();//前端获取数据
        logger.info("开始查询" + departTimeGet + "," + oStationCode + "-" + dStationCode + "的路径信息");
        Date lastAndWaitDate = checkNeedBeforeDate(departTimeGet);
        String responseSign = odPathRequestMessage.getSign();
        String responseCode = "ERROR";
        String responseMsg = "请求失败";
        //step2.获取当前odPath的版本号
        String param_code = "VER_OD_PATH";
        gzdt_553 runVersion = gzdt_553.findDataVersion(param_code);
        String OdPathDataVersion;
        if (runVersion != null) {
            OdPathDataVersion = runVersion.getParam_value();
            //step3. 依据出发站、目的站、出发时刻及路径版本获取path路径
            List<gzdt_553> paths = calculateODPath(oStationCode, dStationCode, departTimeGet, OdPathDataVersion, lastAndWaitDate);
            List<gzdt_553> finalPaths = new ArrayList<>();
            if (!CollectionUtils.isEmpty(paths)) {
                PassFavCoefficient passFavCoefficient = gzdt_553.findFavCoefficient(userId, "user");
                //step4.为路径计算推荐效用
                for (com.bjjdsy.pojo.gzdt_553 gzdt_5532 : finalPaths) {
                    setLogit(gzdt_5532,passFavCoefficient);
                }
                //step5.为路径计算并设置对应的标签信息和满在绿对应的颜色
                for (com.bjjdsy.pojo.gzdt_553 gzdt_5531 : finalPaths) {
                    //求各个标签中的min
                    MinTypeValues minTypeValues = findMinTypeValue(finalPaths, gzdt_5531);
                    //打标签和计算标签总数
                    List<String> typeList = setTypes(gzdt_5531, minTypeValues.getOverallbest(), minTypeValues.getTimeleast(), minTypeValues.getTransferLeast(), minTypeValues.getWaitLeast(), minTypeValues.getLoadmin());
                    String recoType = typeList.get(0);
                    //满载率颜色
                    gzdt_5531.setLoad_rate_color(getLoadRateColor(gzdt_5531.getLoad_rate()));
                    gzdt_5531.setRecoType(recoType);
                }
                BasePassFavLevel basePassFavLevel = basePassFavLevelService.findPassFavLevel(userId);
                //step6.构建响应参数
                odPathResponseDataList = buildOdPathResponseDataList(basePassFavLevel, finalPaths, oStationCode, dStationCode, departTimeGet);
                responseCode = "OK";
                responseMsg = "请求成功";
            } else {
                logger.info("base_od_path_info中无当前版本号的数据");
            }
        } else {
            logger.info("param_runtime缺少当前odPath的版本号");
        }

        OdPathResponseMessage odPathResponseMessage = new OdPathResponseMessage();
        List<JSONObject> jsonList = odPathResponseDataList.stream().map(data -> JSONObject.parseObject(JSONObject.toJSONString(data))).collect(Collectors.toList());
        odPathResponseMessage.setData(jsonList);
        odPathResponseMessage.setMsg(responseMsg);
        odPathResponseMessage.setCode(responseCode);
        odPathResponseMessage.setSign(responseSign);

        logger.info("路径推荐查询结束");
        return odPathResponseMessage;
    }

    /**
     * 已完成
     *
     * @param ReqMsg oStationCode dStationCode pathIndex departTime x-www-form-urlencoded格式
     * @return OdPathDetailResponseMessage
     */
    @CrossOrigin
    @RequestMapping(value = "/v2/gzdtapp/odpath/detail", method = RequestMethod.POST)
    public OdPathDetailResponseMessage pathdetail(@RequestBody String ReqMsg) throws ParseException {

        Date systemDateNow = new Date();


        Date yesterdayDateNow = DateMinus1(systemDateNow, "yyyy-MM-dd", -1);
        Date theDayBeforeYesterdayDateNow = DateMinus1(systemDateNow, "yyyy-MM-dd", -2);
        logger.info("yesterdayDateNow: " + yesterdayDateNow);
        logger.info("theDayBeforeYesterdayDateNow: " + theDayBeforeYesterdayDateNow);

        OdPathDetailTimesRequestMessage odPathDetailTimesRequestMessage = JSONObject.parseObject(ReqMsg, OdPathDetailTimesRequestMessage.class);

        List<JSONObject> pathdetail = new ArrayList<>();

        String oStationCode = odPathDetailTimesRequestMessage.getData().getoStationCode();//前端获取数据
        String dStationCode = odPathDetailTimesRequestMessage.getData().getdStationCode();//前端获取数据
        String pathIndex1 = odPathDetailTimesRequestMessage.getData().getPathIndex();//前端获取数据
        String departTimeget = odPathDetailTimesRequestMessage.getData().getDepartTime();//前端获取数据

        String responseSign = odPathDetailTimesRequestMessage.getSign();
        String responseCode = "ERROR";
        String responseMsg = "请求失败";

        logger.info("开始查询" + oStationCode + "-" + dStationCode + "路径的详细信息");
        //转化时间格式
//        Date departTime = getDateTime(departTimeget);
//        logger.info("departTime:" + departTime);


        Date timeNow;//定义时间

        Integer pathIndex = null;//转换格式
        if (pathIndex1 != null) {
            pathIndex = Integer.valueOf(pathIndex1);
        }

        //找到当前odpath的版本号
        String param_code = "VER_OD_PATH";
        gzdt_553 runVersion = gzdt_553.findDataVersion(param_code);
        String OdPathdataVersion = runVersion.getParam_value();


        if (runVersion.getParam_value() != null) {
            List<gzdt_553> path = gzdt_553.findbyODIndex(oStationCode, dStationCode, pathIndex, OdPathdataVersion, "user");


            if (path.size() != 0) {


                Date LastAndWaitDate = new Date();
                //凌晨4点
                Integer timeThreshold = manageTimeThresholdService.findTimeThresholdByType();
                if (timeThreshold == null) {
                    timeThreshold = 4;
                }

                if (Integer.valueOf(departTimeget.substring(8, 10)) < timeThreshold) {
                    logger.info("末班车和时刻表需要用前一天的数据");
//                    ifNeedBeforeDate = true;
                    LastAndWaitDate = DateMinus1(getDateTime(departTimeget), "yyyy-MM-dd HH:mm:ss", -1);

                } else {
                    logger.info("末班车和时刻表需要用当天的数据");
                    LastAndWaitDate = getDateTime(departTimeget);
                }

                //末班车
                logger.info("LastAndWaitDate:" + LastAndWaitDate);

                //找到有数据的时刻表版本
                String timetableVersion = findTimeTableVersion(LastAndWaitDate);
                //找到有数据的末班车版本
                String MBCdataVersion = findOdPathLastTimeVersion(LastAndWaitDate, oStationCode, dStationCode);


                for (com.bjjdsy.pojo.gzdt_553 gzdt_5531 : path) {
                    Date departTime = getDateTime(departTimeget);
//                    logger.info("departTime:" + departTime);

                    timeNow = departTime;
                    JSONArray stations = new JSONArray();
                    Integer id = gzdt_5531.getRecord_id();
                    String strid = Integer.toString(id);
                    String path_station = gzdt_5531.getPath_stations();
                    String[] sArray = path_station.split("-");
                    //拆解得到所有的车站数字编码
                    List<String> stationList = new ArrayList<>(Arrays.asList(sArray));

                    //判断o站/d站是否是换乘站
                    param_code = "VER_NET_PARAM";
                    gzdt_553 netVersion = gzdt_553.findDataVersion(param_code);

                    if (netVersion != null) {
                        String netDataVersion = netVersion.getParam_value();
                        String OtransStationCode = oStationCode;
                        String DtransStationCode = dStationCode;

                        if (gzdt_553.findStationName(stationList.get(0), netDataVersion, "user").size() != 0) {
                            deleteRepetitiveStationResult deleteResult = deleteRepetitiveStation(stationList, netDataVersion, oStationCode, OtransStationCode, dStationCode, DtransStationCode);

                            oStationCode = deleteResult.getoStationCode();
                            OtransStationCode = deleteResult.getOtransStationCode();
                            stationList = deleteResult.getStationList();
                            dStationCode = deleteResult.getdStationCode();
                            DtransStationCode = deleteResult.getDtransStationCode();

                            Integer totalTime = 0;

//                            logger.info("odpathDetail-start");
                            List<gzdt_553> OdpathDetail = gzdt_553.findDetailbyId(strid);
//                            logger.info("odpathDetail-end");

                            if (OdpathDetail.size() != 0) {


                                //遍历路径中的各个区间
                                for (int i = 0; i < OdpathDetail.size() - 1; i++) {
                                    Integer waitTime = 0;
//                                    String oS = stationList.get(z - 1);
//                                    String oD = stationList.get(z);
                                    String oS = OdpathDetail.get(i).getO_station_code_detail();
                                    String oD = OdpathDetail.get(i).getD_station_code_detail();
                                    String beforeOs = "";


                                    String overrun_up_down = "";
                                    String overrun_beforeOs_transStationCode = "";

                                    if (gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user") != null) {
                                        //区间上下行
                                        overrun_up_down = gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user").getUp_down();

                                    }

                                    String oSName = gzdt_553.findStationName(oS, netDataVersion, "user").get(0).getStation_name();
                                    String dSName = gzdt_553.findStationName(oD, netDataVersion, "user").get(0).getStation_name();

//                                    List<gzdt_553> stationDetail = gzdt_553.findbyODId(oS, oD, strid, "user");

                                    List<Integer> delayTime = new ArrayList<>();

//                                    if (stationDetail.size() != 0) {
                                    JSONObject station = new JSONObject();//新建JSON对象

                                    String transStationCode = OdpathDetail.get(i).getTrans_station_code();

                                    if (transStationCode != null) {

//                                            beforeOs = stationList.get(z - 3);
                                        beforeOs = OdpathDetail.get(OdpathDetail.get(i).getPath_station_index() - 2).getO_station_code_detail();


                                        overrun_beforeOs_transStationCode = gzdt_553.findSectionMessageByOD(beforeOs, transStationCode, netDataVersion, "user").getUp_down();

                                    }

                                    String transLineAfcCode = OdpathDetail.get(i).getTrans_line_afc_code();

                                    if (OdpathDetail.get(i).getPath_station_index().equals(1)) {
//                                        if (z == 1) {

                                        //车站数字编码转换成车站名
                                        String stationName = gzdt_553.findStationName(oStationCode, netDataVersion, "user").get(0).getStation_name();
                                        //依据车站名获取数字编码
                                        List<String> stationCodeList = gzdt_553.findStationCode(netDataVersion, stationName, "user");

                                        //去重，针对311体育西路
                                        Set<String> set = new HashSet<>(stationCodeList);
                                        List<String> newStationCodeList = new ArrayList<>(set);

                                        //单独处理节假日前1天和节假日类型的常态限流
                                        //常态进站限流影响oStationCode, departTimeget, timeNow, totalTime, waitTime
                                        NormalStationLimit normalEntranceLimit = new NormalStationLimit();
                                        normalEntranceLimit = getNormalEntranceLimit(oStationCode, oD, OdpathDetail.get(i).getLine_afc_code(), departTimeget, timeNow, waitTime, newStationCodeList);

                                        delayTime.add(normalEntranceLimit.getMinDelayTime());
                                        delayTime.add(normalEntranceLimit.getMaxDelayTime());
                                        //进站候车时间
//                                        waitTime = calculateWaitTime(ifNeedBeforeDate, timeNow, waitTime, oS, oD, stationDetail, timetableVersion);
                                        waitTime = findWaitTime(timeNow, oS, oD, waitTime, OdpathDetail.get(i), timetableVersion);
                                    } else {
                                        if (transStationCode != null) {

                                            NormalStationLimit normalStationLimit = new NormalStationLimit();//oS,oD,stationDetail.get(0).getLineName(),timeNow, totalTime, waitTime, transStationCode
                                            normalStationLimit = getNormalLimit(oS, oD, OdpathDetail.get(i).getLine_afc_code(), timeNow, waitTime, transStationCode, transLineAfcCode);

                                            delayTime.add(normalStationLimit.getMinDelayTime());
                                            delayTime.add(normalStationLimit.getMaxDelayTime());

//                                            waitTime = calculateWaitTime(ifNeedBeforeDate, timeNow, waitTime, oS, oD, stationDetail, timetableVersion);
                                            waitTime = findWaitTime(timeNow, oS, oD, waitTime, OdpathDetail.get(i), timetableVersion);
                                        }
                                    }

                                    //查找满载率
                                    String shike = getDataToFormatString(timeNow, "HH:mm:ss");
                                    String HHmm = getDataToFormatString(timeNow, "HH:mm");
                                    List<gzdt_553> load = new ArrayList<>();
                                    //与T-2比较
                                    if (theDayBeforeYesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {

//                                        logger.info("T-2及以前使用历史满载率");
                                        //查找历史满载率
                                        load = getHisLoadRate(oS, oD, departTime, HHmm, shike);
                                    } else {
//                                        logger.info("查找特征满载率");
                                        //查找特征满载率
                                        load = getLoadRate(oS, oD, departTime, shike);
                                    }

                                    if (load.size() != 0) {
                                        OdpathDetail.get(i).setLoad_rate(load.get(0).getLoad_rate());

                                    } else {
                                        //没有满载率时
                                        OdpathDetail.get(i).setLoad_rate(0.0);

                                    }

                                    //满载率颜色
                                    OdpathDetail.get(i).setLoad_rate_color(getLoadRateColor(OdpathDetail.get(i).getLoad_rate()));

                                    String directStationCode = OdpathDetail.get(i).getDirect_station_code();
                                    String directStationName = gzdt_553.findStationName(directStationCode, netDataVersion, "user").get(0).getStation_name();

                                    String lineAfcCode = OdpathDetail.get(i).getLine_afc_code();
                                    Integer travelTime = OdpathDetail.get(i).getTravel_time();
                                    Integer transTime = OdpathDetail.get(i).getTrans_time();
                                    Integer stationType = OdpathDetail.get(i).getPath_station_type();

                                    String lineName = gzdt_553.findLineName(netDataVersion, lineAfcCode, "user");
                                    if (lineName == null) {
                                        lineName = "";
                                    }
                                    //英文lineName
                                    String enLineName = gzdt_553.findLineEnName(netDataVersion, lineName, "user");
                                    station.put("enLineName", enLineName);

                                    //英文stationName
                                    String enStationName = gzdt_553.findStationEnName(netDataVersion, oS, lineAfcCode);
                                    station.put("enStationName", enStationName);

                                    //英文stationName
                                    String enDSName = gzdt_553.findStationEnName(netDataVersion, oD, lineAfcCode);

                                    //处理突发
                                    //新增处理历史突发事件
                                    if (yesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {

                                        logger.info("出发时间早于前一天时间！查询日期为历史信息，不提示突发事件");

                                        station.put("eventLimitTime", "");
                                        station.put("enEventLimitTime", "");

                                        station.put("enEmerPasFlowConTime", "");
                                        station.put("enEmerPasFlowConTime", "");

                                    } else {
                                        logger.info("查询日期为新的信息，提醒突发事件");

                                        EventInfluence eventInfluence = getEventInfluence(timeNow, transStationCode, gzdt_5531, oStationCode, dStationCode, oD, oS, OtransStationCode, DtransStationCode, beforeOs, overrun_up_down, overrun_beforeOs_transStationCode, systemDateNow, transLineAfcCode, lineAfcCode);
                                        //                                        boolean isEventInfluence = eventInfluence.isInfluence();

                                        boolean eventPassengerFlowControl = eventInfluence.isEventPassengerFlowControl();
                                        boolean overrun = eventInfluence.isOverrun();
                                        boolean delaysOrInterruptions = eventInfluence.isDelaysOrInterruptions();
                                        String overrunOCode = eventInfluence.getOverrunOCode();
//                                        String overrunDCode = eventInfluence.getOverrunDCode();
                                        String overrunDirection = eventInfluence.getOverrunDirection();
                                        String overrunLineAfcCode = eventInfluence.getOverrunLineAfcCode();

                                        //                                        gzdt_5531.setInfluence(eventInfluence.isInfluence());
                                        logger.info("gzdt_5531.isInfluence():" + gzdt_5531.isInfluence());
                                        //                                        station.put("eventLimitTime", "");
                                        //                                        station.put("enEventLimitTime", "");

                                        //先判断该区间是否受突发影响
                                        if (gzdt_5531.isSectionEventInfluence()) {
                                            //延误、中断整个路径都受影响
                                            logger.info("delaysOrInterruptions:" + delaysOrInterruptions);
                                            if (delaysOrInterruptions == true) {

                                                String eventEmergencyLineAfcCode = eventInfluence.getEventEmergencyLineAfcCode();
                                                String eventEmergencyOSCode = eventInfluence.getEventEmergencyOSCode();
                                                String eventEmergencyDSCode = eventInfluence.getEventEmergencyDSCode();

                                                logger.info("eventEmergencyOSCode.substring(eventEmergencyOSCode.length()-2):" + eventEmergencyOSCode.substring(eventEmergencyOSCode.length() - 2));
                                                Integer eventEmergencyOSCodeNum = Integer.valueOf(eventEmergencyOSCode.substring(eventEmergencyOSCode.length() - 2));
                                                Integer eventEmergencyDSCodeNum = Integer.valueOf(eventEmergencyDSCode.substring(eventEmergencyDSCode.length() - 2));
                                                Integer OSCodeNum = Integer.valueOf(oS.substring(oS.length() - 2));
                                                Integer DSCodeNum = Integer.valueOf(oD.substring(oD.length() - 2));

                                                String emergencyOSCode = eventEmergencyOSCode;
                                                String emergencyDSCode = eventEmergencyDSCode;

                                                if ((eventEmergencyOSCodeNum < eventEmergencyDSCodeNum && OSCodeNum < DSCodeNum) || (eventEmergencyOSCodeNum > eventEmergencyDSCodeNum && OSCodeNum > DSCodeNum)) {
                                                    //同号不用交换
//                                                    emergencyOSCode = eventEmergencyOSCode;
//                                                    emergencyDSCode = eventEmergencyDSCode;
                                                } else {
                                                    emergencyOSCode = eventEmergencyDSCode;
                                                    emergencyDSCode = eventEmergencyOSCode;
                                                }


                                                String emergencyLineAfcCodeName = gzdt_553.findLineName(netDataVersion, eventEmergencyLineAfcCode, "user");
                                                String emergencyOSCodeName = gzdt_553.findStationName(emergencyOSCode, netDataVersion, "user").get(0).getStation_name();
                                                String emergencyDSCodeName = gzdt_553.findStationName(emergencyDSCode, netDataVersion, "user").get(0).getStation_name();

                                                String enEmergencyLineAfcCodeName = gzdt_553.findLineEnName(netDataVersion, emergencyLineAfcCodeName, "user");


                                                //英文stationName
                                                String enEmergencyOSCodeName = gzdt_553.findStationEnName(netDataVersion, emergencyOSCode, eventEmergencyLineAfcCode);
                                                String enEmergencyDSCodeName = gzdt_553.findStationEnName(netDataVersion, emergencyDSCode, eventEmergencyLineAfcCode);


                                                station.put("eventLimitTime", "因" + emergencyLineAfcCodeName + emergencyOSCodeName + "-" + emergencyDSCodeName + "区段受突发事件影响，可能需额外等待。");
                                                station.put("enEventLimitTime", "Due to the emergency in the section between " + enEmergencyOSCodeName + " Station and " + enEmergencyDSCodeName + " Station on " + enEmergencyLineAfcCodeName + ", you may face an additional waiting.");

//                                                station.put("eventLimitTime", "因" + lineName + oSName + "-" + dSName + "区段受突发事件影响，可能需额外等待。");
//                                                station.put("enEventLimitTime", "Due to the emergency in the section between " + enStationName + " Station and " + enDSName + " Station on " + enLineName + ", you may face an additional waiting.");

                                            } else if (overrun == true) {

                                                ParamSection overrunMessage = gzdt_553.findSectionMessageByODirectionLineAfc(overrunOCode, overrunDirection, netDataVersion, overrunLineAfcCode);

//                                                ParamSection overrunMessage = gzdt_553.findSectionMessageByODirection(overrunOCode, overrunDirection, netDataVersion);

                                                logger.info("overrunMessage.getLine_afc_code():" + overrunMessage.getLine_afc_code());
                                                String overLineName = gzdt_553.findLineName(netDataVersion, overrunMessage.getLine_afc_code(), "user");

                                                String overStationName = gzdt_553.findStationName(overrunOCode, netDataVersion, "user").get(0).getStation_name();

                                                String overDirectionStationName = gzdt_553.findStationName(overrunMessage.getDirect_station_code(), netDataVersion, "user").get(0).getStation_name();

                                                String enOverDirectionStationName = gzdt_553.findStationEnName(netDataVersion, overrunMessage.getDirect_station_code(), overrunMessage.getLine_afc_code());

                                                String enOverStationName = gzdt_553.findStationEnName(netDataVersion, overrunOCode, lineAfcCode);

                                                String enOverLineName = gzdt_553.findLineEnName(netDataVersion, overLineName, "user");

                                                station.put("eventLimitTime", "因" + overLineName + overStationName + "开往" + overDirectionStationName + "方向列车越站，可能无法到达目的地。");
                                                station.put("enEventLimitTime", "Because the train bound for " + enOverDirectionStationName + " Station will pass through " + enOverStationName + " Station of " + enOverLineName + " without stop, you may not reach the destination.");

                                            } else {
                                                station.put("eventLimitTime", "");
                                                station.put("enEventLimitTime", "");
                                            }
//                                            else if (eventPassengerFlowControl == true) {
////                                                station.put("eventLimitTime", "因突发客流控制，可能需额外等待。");
////                                                station.put("enEventLimitTime", "Due to sudden passenger flow control, you may face an additional waiting.");
//
//                                                station.put("emerPasFlowConTime", "因突发客流控制，可能需额外等待。");
//                                                station.put("enEmerPasFlowConTime", "Due to sudden passenger flow control, you may face an additional waiting.");
//
//                                            }

                                            if (eventPassengerFlowControl == true) {
                                                station.put("emerPasFlowConTime", "因突发客流控制，可能需额外等待。");
                                                station.put("enEmerPasFlowConTime", "Due to sudden passenger flow control, you may face an additional waiting.");

                                            } else {
                                                station.put("emerPasFlowConTime", "");
                                                station.put("enEmerPasFlowConTime", "");

                                            }

                                        } else {
                                            //该区间不受突发影响
                                            station.put("eventLimitTime", "");
                                            station.put("enEventLimitTime", "");

                                            station.put("emerPasFlowConTime", "");
                                            station.put("enEmerPasFlowConTime", "");
                                        }

                                    }


                                    timeNow.setTime(timeNow.getTime() + (travelTime + waitTime + transTime) * 1000);

                                    totalTime = totalTime + travelTime + waitTime + transTime;

                                    //英文directStationName
                                    String enDirectStationName = gzdt_553.findStationEnName(netDataVersion, directStationCode, lineAfcCode);
                                    station.put("enDirectStationName", enDirectStationName);

//                                        station.put("stationCode", stationList.get(z - 1));
                                    station.put("stationCode", OdpathDetail.get(i).getO_station_code_detail());
                                    station.put("stationName", oSName);
                                    station.put("directStationName", directStationName);
                                    station.put("lineName", lineName);
                                    station.put("travelTime", travelTime + waitTime + transTime);
                                    station.put("stationType", stationType);
                                    station.put("loadRate", OdpathDetail.get(i).getLoad_rate());
                                    //拥挤度颜色
                                    station.put("loadRateColor", OdpathDetail.get(i).getLoad_rate_color());

                                    if (delayTime.size() != 0 && delayTime.get(0) != 0) {
                                        station.put("delayTime", "因客流控制，可能多等" + delayTime.get(0) + "-" + delayTime.get(1) + "分钟。");
                                        station.put("enDelayTime", "Due to passenger flow control, you may wait " + delayTime.get(0) + "-" + delayTime.get(1) + " minutes longer.");
                                    } else {
                                        station.put("delayTime", "");
                                        station.put("enDelayTime", "");
                                    }

                                    stations.add(station);

//                                    } else {
//                                        logger.info(oS + "-" + oD + "base_od_path_detail表中缺少数据");
//                                    }

                                }

                            } else {
                                logger.info(strid + "：base_od_path_detail表中缺少" + strid + "对应的数据");
                            }

                            //终点站信息
                            JSONObject station = new JSONObject();//新建JSON对象


                            if (netVersion != null) {

                                List<gzdt_553> staName = gzdt_553.findStationName(dStationCode, netDataVersion, "user");
                                if (staName.size() != 0) {

                                    String lineName = gzdt_553.findLineName(netDataVersion, staName.get(0).getLine_afc_code(), "user");
                                    if (lineName == null) {
                                        lineName = "";
                                    }

                                    //英文directStationName
                                    station.put("enDirectStationName", "");

                                    //英文lineName
                                    String enLineName = gzdt_553.findLineEnName(netDataVersion, lineName, "user");
                                    station.put("enLineName", enLineName);

                                    //英文stationName
                                    String enStationName = gzdt_553.findStationEnName(netDataVersion, dStationCode, staName.get(0).getLine_afc_code());
                                    station.put("enStationName", enStationName);

                                    station.put("stationCode", dStationCode);
                                    station.put("stationName", staName.get(0).getStation_name());
                                    station.put("directStationName", "");
                                    station.put("lineName", lineName);
                                    station.put("travelTime", "");
                                    station.put("stationType", 4);
                                    station.put("loadRate", "");
                                    //拥挤度颜色
                                    station.put("loadRateColor", "");
                                    station.put("delayTime", "");

                                    //区间上下行
                                    String dStationCode_up_down = "";
                                    String beforedStationCode = stationList.get(stationList.size() - 2);
                                    logger.info("beforedStationCode:" + beforedStationCode);

                                    if (gzdt_553.findSectionMessageByOD(beforedStationCode, dStationCode, netDataVersion, "user") != null) {


                                        dStationCode_up_down = gzdt_553.findSectionMessageByOD(beforedStationCode, dStationCode, netDataVersion, "user").getUp_down();

                                    }
                                    logger.info("dStationCode_up_down:" + dStationCode_up_down);

                                    //处理突发
                                    if (yesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {

                                        logger.info("出发时间早于前一天时间！查询日期为历史信息，不提示突发事件");

                                        station.put("eventLimitTime", "");
                                        station.put("enEventLimitTime", "");

                                        station.put("enEmerPasFlowConTime", "");
                                        station.put("enEmerPasFlowConTime", "");

                                    } else {
                                        logger.info("查询日期为新的信息，提醒突发事件");

                                        EventInfluence eventInfluence = getEventInfluence(timeNow, null, gzdt_5531, oStationCode, dStationCode, "", dStationCode, OtransStationCode, DtransStationCode, "", dStationCode_up_down, "", systemDateNow, "", "");


                                        boolean eventPassengerFlowControl = eventInfluence.isEventPassengerFlowControl();
                                        boolean overrun = eventInfluence.isOverrun();
                                        boolean delaysOrInterruptions = eventInfluence.isDelaysOrInterruptions();
                                        String overrunOCode = eventInfluence.getOverrunOCode();
                                        String overrunDirection = eventInfluence.getOverrunDirection();
                                        String overrunLineAfcCode = eventInfluence.getOverrunLineAfcCode();

                                        if (gzdt_5531.isSectionEventInfluence()) {
                                            //越行，只有当前车站受影响

                                            if (overrun == true) {

                                                ParamSection overrunMessage = gzdt_553.findSectionMessageByODirectionLineAfc(overrunOCode, overrunDirection, netDataVersion, overrunLineAfcCode);

//                                                ParamSection overrunMessage = gzdt_553.findSectionMessageByODirection(overrunOCode, overrunDirection, netDataVersion);

//                                                ParamSection overrunMessage = gzdt_553.findSectionMessageByOD(overrunOCode, overrunDCode, netDataVersion, "user");

                                                logger.info("overrunMessage.getLine_afc_code():" + overrunMessage.getLine_afc_code());
                                                String overLineName = gzdt_553.findLineName(netDataVersion, overrunMessage.getLine_afc_code(), "user");

                                                String overStationName = gzdt_553.findStationName(overrunOCode, netDataVersion, "user").get(0).getStation_name();

                                                String overDirectionStationName = gzdt_553.findStationName(overrunMessage.getDirect_station_code(), netDataVersion, "user").get(0).getStation_name();

//                                                String enOverDirectionStationName = gzdt_553.findStationEnName(netDataVersion, overrunMessage.getDirect_station_code(), staName.get(0).getLine_afc_code());
                                                String enOverDirectionStationName = gzdt_553.findStationEnName(netDataVersion, overrunMessage.getDirect_station_code(), staName.get(0).getLine_afc_code());

                                                String enOverStationName = gzdt_553.findStationEnName(netDataVersion, overrunOCode, staName.get(0).getLine_afc_code());

                                                String enOverLineName = gzdt_553.findLineEnName(netDataVersion, overLineName, "user");


                                                station.put("eventLimitTime", "因" + overLineName + overStationName + "开往" + overDirectionStationName + "方向列车越站，可能无法到达目的地。");
                                                station.put("enEventLimitTime", "Because the train bound for " + enOverDirectionStationName + " Station will pass through " + enOverStationName + " Station of " + enOverLineName + " without stop, you may not reach the destination.");

                                            } else {
                                                station.put("eventLimitTime", "");
                                                station.put("enEventLimitTime", "");

                                            }

                                            station.put("enEmerPasFlowConTime", "");
                                            station.put("enEmerPasFlowConTime", "");

                                        } else {
                                            station.put("eventLimitTime", "");
                                            station.put("enEventLimitTime", "");

                                            station.put("enEmerPasFlowConTime", "");
                                            station.put("enEmerPasFlowConTime", "");
                                        }

                                    }

                                    station.put("enDelayTime", "");
                                    stations.add(station);

                                    //末班车
                                    OdPathDetailResponseData data = new OdPathDetailResponseData();
                                    data.setTicketPrice(gzdt_5531.getTicket_price());

                                    data.setStationAmount(gzdt_5531.getStation_amount());
                                    data.setTransAmount(gzdt_5531.getTrans_amount());
                                    //返回所有颜色字段
                                    data.setAllLoadRateColor(getAllLoadRateColor());

                                    data.setTotalTime(totalTime);

                                    //末班车
//                                    String pathStations = path.get(0).getPath_stations();

//                                    List<BaseOdPathLast> finalTime = gzdt_553.findOdPathFinalTime(MBCdataVersion, path_station);

                                    List<BaseOdPathLast> finalTime = gzdt_553.findFinalTime(oStationCode, dStationCode, MBCdataVersion, path_station, "user");


                                    if (finalTime.size() != 0) {
                                        data.setLastTime(finalTime.get(0).getLast_time());
                                        logger.info("末班车-data.getLastTime():" + data.getLastTime());

                                    } else {
                                        logger.info("数据库中无末班车的默认数据！");
                                        data.setLastTime("");
                                    }

                                    data.setStations(stations);

                                    //xinjia
                                    JSONObject json = (JSONObject) JSONObject.toJSON(data);
                                    pathdetail.add(json);
                                    responseCode = "OK";
                                    responseMsg = "请求成功";

                                } else {
                                    logger.info("param_station中无当前版本号的数据");
                                }
                            } else {
                                logger.info("param_runtime缺少当前net的版本号");
                            }

                        } else {
                            logger.info("param_station缺少当前net的版本号对应的数据");
                        }


                    } else {
                        logger.info("param_runtime缺少当前net的版本号");
                    }

                }

            } else {
                logger.info("base_od_path_info中无当前版本号的数据");
            }
        } else {
            logger.info("param_runtime缺少当前odPath的版本号");
        }

        OdPathDetailResponseMessage odPathDetailResponseMessage = new OdPathDetailResponseMessage();

        odPathDetailResponseMessage.setData(pathdetail);
        odPathDetailResponseMessage.setMsg(responseMsg);
        odPathDetailResponseMessage.setCode(responseCode);
        odPathDetailResponseMessage.setSign(responseSign);

        logger.info(oStationCode + "-" + dStationCode + "的路径详情查询完毕！");
        return odPathDetailResponseMessage;
    }


    /**
     * 考虑了进站限流以及突发事件影响
     *
     * @param ReqMsg oStationCode dStationCode pathIndex departTime x-www-form-urlencoded格式
     * @return OdPathTimesResponseMessage
     */
    @CrossOrigin
    @RequestMapping(value = "/v2/gzdtapp/odpath/times", method = RequestMethod.POST)
    public OdPathTimesResponseMessage pathtimes(@RequestBody String ReqMsg) throws ParseException {

        OdPathDetailTimesRequestMessage odPathDetailTimesRequestMessage = JSONObject.parseObject(ReqMsg, OdPathDetailTimesRequestMessage.class);
        String oStationCode = odPathDetailTimesRequestMessage.getData().getoStationCode();//前端获取数据
        String dStationCode = odPathDetailTimesRequestMessage.getData().getdStationCode();//前端获取数据
        String pathIndex1 = odPathDetailTimesRequestMessage.getData().getPathIndex();//前端获取数据
        String departTimeget = odPathDetailTimesRequestMessage.getData().getDepartTime();//前端获取数据

        String responseSign = odPathDetailTimesRequestMessage.getSign();
        String responseCode = "ERROR";
        String responseMsg = "请求失败";

        //基础数据格式转换
        Date departTime = getDateTime(departTimeget);
        Integer pathIndex = null;
        if (pathIndex1 != null) {
            pathIndex = Integer.valueOf(pathIndex1);
        }

        //新建JSON对象
        List<JSONObject> totalTimes = new ArrayList<>();

        Date departTimeData = new Date();
        Date departTimeDataNow = new Date();

        OdPathTimesResponseData data = new OdPathTimesResponseData();

        //找到当前odpath的版本号
        String param_code = "VER_OD_PATH";
        gzdt_553 runVersion = gzdt_553.findDataVersion(param_code);
        String OdPathDataVersion = runVersion.getParam_value();

        if (runVersion.getParam_value() != null) {
            List<gzdt_553> path = gzdt_553.findbyODIndex(oStationCode, dStationCode, pathIndex, OdPathDataVersion, "user");
            if (path.size() != 0) {

                for (Long departTimeNow = departTime.getTime() - 60 * 60 * 1000; departTimeNow <= departTime.getTime() + 60 * 60 * 1000; departTimeNow = departTimeNow + 15 * 60 * 1000) {


                    JSONObject times = new JSONObject();//新建JSON对象

                    departTimeData.setTime(departTimeNow);
                    departTimeDataNow.setTime(departTimeData.getTime());

                    Integer totalTime = 0;
                    Integer pathTotalTime = totalTime;
                    Integer id = path.get(0).getRecord_id();
                    String strid = Integer.toString(id);
                    String path_station = path.get(0).getPath_stations();
                    String[] sArray = path_station.split("-");
                    List<String> stationList = new ArrayList<>(Arrays.asList(sArray));

                    //判断o站/d站是否是换乘站
                    param_code = "VER_NET_PARAM";
                    gzdt_553 netVersion = gzdt_553.findDataVersion(param_code);

//                    boolean ifNeedBeforeDate = false;

                    if (netVersion != null) {
                        String netDataVersion = netVersion.getParam_value();
                        String OtransStationCode = oStationCode;
                        String DtransStationCode = dStationCode;

                        //得到出发时间的时分秒
                        Date LastAndWaitDate = new Date();
                        //凌晨4点
                        Integer timeThreshold = manageTimeThresholdService.findTimeThresholdByType();
                        if (timeThreshold == null) {
                            timeThreshold = 4;
                        }

                        if (Integer.valueOf(departTimeget.substring(8, 10)) < timeThreshold) {
                            logger.info("末班车和时刻表需要用前一天的数据");
//                            ifNeedBeforeDate = true;
                            LastAndWaitDate = DateMinus1(getDateTime(departTimeget), "yyyy-MM-dd HH:mm:ss", -1);

                        } else {
                            logger.info("末班车和时刻表需要用当天的数据");
                            LastAndWaitDate = getDateTime(departTimeget);
                        }
//                        if (getFormatDate(departTimeget, "HH").getTime() < getFormatDate("04", "HH").getTime()) {
//                            logger.info("末班车和时刻表需要用前一天的数据");
////                            ifNeedBeforeDate = true;
//                            LastAndWaitDate = DateMinus1(getDateTime(departTimeget), "yyyy-MM-dd HH:mm:ss", -1);
//
//                        } else {
//                            logger.info("末班车和时刻表需要用当天的数据");
//                            LastAndWaitDate = getDateTime(departTimeget);
//                        }

                        //末班车
                        logger.info("LastAndWaitDate:" + LastAndWaitDate);

                        //找到有数据的时刻表版本
                        String timetableVersion = findTimeTableVersion(LastAndWaitDate);
                        //找到有数据的末班车版本
//                        String MBCdataVersion = findOdPathLastTimeVersion(LastAndWaitDate);


                        if (gzdt_553.findStationName(stationList.get(0), netDataVersion, "user").size() != 0) {


                            deleteRepetitiveStationResult deleteResult = deleteRepetitiveStation(stationList, netDataVersion, oStationCode, "", dStationCode, "");
                            oStationCode = deleteResult.getoStationCode();
                            stationList = deleteResult.getStationList();
                            dStationCode = deleteResult.getdStationCode();
                            OtransStationCode = deleteResult.getOtransStationCode();
                            DtransStationCode = deleteResult.getDtransStationCode();

                            //各个区间
                            for (int z = 1, m = stationList.size(); z < m; z++) {
                                String oS = stationList.get(z - 1);
                                String oD = stationList.get(z);

                                Integer waitTime = 0;

                                List<gzdt_553> stationdetail = gzdt_553.findbyODId(oS, oD, strid, "user");

                                if (stationdetail.size() != 0) {

                                    String transStationCode = stationdetail.get(0).getTrans_station_code();
                                    if (z == 1) {

                                        //进站候车时间
//                                        waitTime = calculateWaitTime(ifNeedBeforeDate, departTimeDataNow, waitTime, oS, oD, stationdetail, timetableVersion);
                                        waitTime = findWaitTime(departTimeDataNow, oS, oD, waitTime, stationdetail.get(0), timetableVersion);
//                                        System.out.println("waitTime: " + waitTime);
                                    } else {
                                        if (transStationCode != null) {

                                            //换乘候车时间
//                                            waitTime = calculateWaitTime(ifNeedBeforeDate, departTimeDataNow, waitTime, oS, oD, stationdetail, timetableVersion);
                                            waitTime = findWaitTime(departTimeDataNow, oS, oD, waitTime, stationdetail.get(0), timetableVersion);

//                                            System.out.println("waitTime: " + waitTime);

                                        }
                                    }

                                    //区间运行时间
                                    Integer travelTime = stationdetail.get(0).getTravel_time();
                                    Integer transTime = stationdetail.get(0).getTrans_time();

                                    departTimeDataNow.setTime(departTimeDataNow.getTime() + (travelTime + waitTime + transTime) * 1000);
                                    pathTotalTime = pathTotalTime + travelTime + waitTime + transTime;

                                } else {
                                    logger.info("base_od_path_detail表中缺少数据");
                                }

                            }

                            times.put("departTime", getDataToFormatString(departTimeData, "yyyyMMddHHmmss"));
                            times.put("totalTime", pathTotalTime);
                            totalTimes.add(times);

                        } else {
                            logger.info("param_station缺少当前net的版本号对应的数据");
                        }

                    } else {
                        logger.info("param_runtime缺少当前net的版本号");
                    }

                }

                data.setTotalTimes(totalTimes);

                responseCode = "OK";
                responseMsg = "请求成功";

            } else {
                logger.info("base_od_path_info中无当前版本号的数据");
            }

        } else {
            logger.info("param_runtime缺少当前odPath的版本号");
        }

        OdPathTimesResponseMessage odPathTimesResponseMessage = new OdPathTimesResponseMessage();
        odPathTimesResponseMessage.setData(data);
        odPathTimesResponseMessage.setCode(responseCode);
        odPathTimesResponseMessage.setMsg(responseMsg);
        odPathTimesResponseMessage.setSign(responseSign);

        return odPathTimesResponseMessage;
    }

    /**
     * 计算得到最小标签值
     *
     * @param
     * @return
     */
    private MinTypeValues findMinTypeValue(List<gzdt_553> path, gzdt_553 gzdt_5531) {
        MinTypeValues minTypeValues = new MinTypeValues();

        //求各个标签中的min
        List times = path.stream().map(com.bjjdsy.pojo.gzdt_553::getTotal_time).collect(Collectors.toList());
        Integer timeleast;

        List transfer = path.stream().map(com.bjjdsy.pojo.gzdt_553::getTrans_amount).collect(Collectors.toList());
        Integer transferLeast;

        List wait = path.stream().map(com.bjjdsy.pojo.gzdt_553::getWait_time).collect(Collectors.toList());
        Integer waitLeast;

        List overall = path.stream().map(com.bjjdsy.pojo.gzdt_553::getV_logit).collect(Collectors.toList());
        double overallbest;

        timeleast = (Integer) min(times);//判断是否时间最短
        transferLeast = (Integer) min(transfer);//判断是否换乘最少
        waitLeast = (Integer) min(wait);//判断是否等待最少
        overallbest = (double) min(overall);//判断是否综合效用最好

        double loadmin = 2;
        if (gzdt_5531.getLoad_rate() != null) {
            List load = path.stream().map(com.bjjdsy.pojo.gzdt_553::getLoad_rate).collect(Collectors.toList());

            loadmin = (double) min(load);

        }

        minTypeValues.setTimeleast(timeleast);
        minTypeValues.setTransferLeast(transferLeast);
        minTypeValues.setWaitLeast(waitLeast);
        minTypeValues.setOverallbest(overallbest);
        minTypeValues.setLoadmin(loadmin);

        return minTypeValues;

    }

    /**
     * 计算路径中各线路的最大满载率
     *
     * @param
     * @return
     */
    private void findMaxLoadByLine(MultiValueMap<String, Double> loadsByLine, gzdt_553 gzdt_5531) {
        //获得路径中各线路最大满载率
        Map<String, Double> loadMaxByLine = new HashMap<>();
        Map<String, Integer> loadMaxLevelByLine = new HashMap<>();

        Set<String> keySet = loadsByLine.keySet();
        for (String key : keySet) {
            List<Double> lineLoad = loadsByLine.get(key);
            loadMaxByLine.put(key, max(lineLoad));
            loadMaxLevelByLine.put(key, getLoadRateLevel(max(lineLoad)));
        }

        //获取按线路划分的满载率集合，并取各线路的max
        if (loadMaxByLine.size() != 0) {
            Collection<Double> c = loadMaxByLine.values();
            gzdt_5531.setLoad_rate(max(c));
            gzdt_5531.setLinesLoadRate(loadMaxByLine);
            gzdt_5531.setLinesLoadLevel(loadMaxLevelByLine);
        } else {
            gzdt_5531.setLoad_rate(0.0);
            gzdt_5531.setLinesLoadRate(loadMaxByLine);
            gzdt_5531.setLinesLoadLevel(loadMaxLevelByLine);
            logger.info("缺少满载率数据");
        }

    }

    /**
     * 候车时间
     *
     * @param
     * @return
     */

//    private Integer findWaitTime(Date timeNow, String oS, String oD, Integer waitTime, List<gzdt_553> stationDetail, String timetableVersion) throws ParseException {
//
//        Integer hour = Integer.valueOf(getDataToFormatString(timeNow, "HH"));
//        if (gzdt_553.findAverageWaitTime(oS, oD, hour.toString(), timetableVersion, "user") != null) {
//            waitTime = waitTime + Integer.valueOf(gzdt_553.findAverageWaitTime(oS, oD, hour.toString(), timetableVersion, "user"));
//        } else {
//            logger.info("没有找到今日、最临近日期类型和default的时刻表的数据版本对应的数据！使用detail版本数据！");
//            waitTime = waitTime + stationDetail.get(0).getWait_time();
//
//        }
//
//        return waitTime;
//    }
    private Integer findWaitTime(Date timeNow, String oS, String oD, Integer waitTime, gzdt_553 stationDetail, String timetableVersion) throws ParseException {

        Integer hour = Integer.valueOf(getDataToFormatString(timeNow, "HH"));
        if (gzdt_553.findAverageWaitTime(oS, oD, hour.toString(), timetableVersion, "user") != null) {
            waitTime = waitTime + Integer.valueOf(gzdt_553.findAverageWaitTime(oS, oD, hour.toString(), timetableVersion, "user"));
        } else {
            logger.info("时刻表没有找到今日、最临近日期类型和default的时刻表的数据版本对应的数据！使用detail版本数据！");
            waitTime = waitTime + stationDetail.getWait_time();

        }

        return waitTime;
    }

    private String findTimeTableVersion(Date timeNow) throws ParseException {


        logger.info("getForDate(timeNow):" + getForDate(timeNow));
        String timetableVersion = gzdt_553.findTimeTableVersion(getForDate(timeNow), "user");

//        logger.info("时刻表有出发日期的时刻表版本," + timetableVersion);

        List<String> averageWaitTime = gzdt_553.findODAverageWaitTime(timetableVersion);

        if (timetableVersion == null || timetableVersion.length() == 0 || averageWaitTime == null || averageWaitTime.size() == 0) {
            logger.info("时刻表出发日期的时刻表版本为：" + timetableVersion + ",数据量：" + averageWaitTime.size());
            //无时刻表查询日期的数据，查找最邻近的同类型日期数据
            Date theDayBeforeDateNow = findNearDateType(timeNow);
            logger.info("findNearDateType" + theDayBeforeDateNow);
            timetableVersion = gzdt_553.findTimeTableVersion(getForDate(theDayBeforeDateNow), "user");
            List<String> averageWaitTimeNear = gzdt_553.findODAverageWaitTime(timetableVersion);

            if (timetableVersion == null || timetableVersion.length() == 0 || averageWaitTimeNear == null || averageWaitTimeNear.size() == 0) {
                logger.info("时刻表最邻近日期的时刻表版本为：" + timetableVersion + ",数据量：" + averageWaitTime.size());
                timetableVersion = "default";
                List<String> averageWaitTimeDefault = gzdt_553.findODAverageWaitTime(timetableVersion);

                if (averageWaitTimeDefault == null || averageWaitTimeDefault.size() == 0) {
                    logger.info("没有default对应的数据");
                    timetableVersion = null;
                }

            }

        }

        logger.info("timetableVersion: " + timetableVersion);

        return timetableVersion;
    }

//    private String findTimeTableVersion(Date timeNow) throws ParseException {
//
//
//        String timetableVersion = gzdt_553.findTimeTableVersion(getForDate(timeNow), "user");
//        //如果没有出发日期的版本则找到最邻近日期的版本
//        if (timetableVersion == null||timetableVersion.equals("")) {
//            logger.info("时刻表没有出发日期的时刻表版本,应找到最邻近日期的版本");
//
//            //无时刻表查询日期的数据，查找最邻近的同类型日期数据
//            //            Date theDayBeforeDateNow = calculateNearDateType(timeNow);
//            Date theDayBeforeDateNow = findNearDateType(timeNow);
//
//            timetableVersion = gzdt_553.findTimeTableVersion(getForDate(theDayBeforeDateNow), "user");
//            if (timetableVersion == null||timetableVersion.equals("")){
//                logger.info("时刻表中最邻近日期的版本为空");
////                timetableVersion="default";
//                List<String> averageWaitTime = gzdt_553.findODAverageWaitTime("default");
//
//                if (averageWaitTime == null || averageWaitTime.size() == 0) {
//                    logger.info("没有default对应的数据");
//                    timetableVersion = null;
//                }
//            }else {
//                List<String> averageWaitTime = gzdt_553.findODAverageWaitTime(timetableVersion);
//
//                if (averageWaitTime == null || averageWaitTime.size() == 0) {
//                    logger.info("时刻表mapping中有" + timetableVersion + ",但是数据表中没有该数据");
//                    List<String> averageWaitTimeDefault = gzdt_553.findODAverageWaitTime("default");
//
//                    if (averageWaitTimeDefault == null || averageWaitTimeDefault.size() == 0) {
//                        logger.info("没有default对应的数据");
//                        timetableVersion = null;
//                    }
//                }
//            }
//////            List<String> averageWaitTime=gzdt_553.findODAverageWaitTime(oStationCode, dStationCode, timetableVersion);
////            List<String> averageWaitTime = gzdt_553.findODAverageWaitTime(timetableVersion);
////
////            if (averageWaitTime == null || averageWaitTime.size() == 0) {
////                logger.info("时刻表mapping中有" + timetableVersion + ",但是数据表中没有该数据");
////                timetableVersion = null;
////            }
//
//        } else {
//            logger.info("时刻表有出发日期的时刻表版本," + timetableVersion);
////            List<String> averageWaitTime=gzdt_553.findODAverageWaitTime(oStationCode, dStationCode, timetableVersion);
//            List<String> averageWaitTime = gzdt_553.findODAverageWaitTime(timetableVersion);
//
////            logger.info("averageWaitTime.size():" + averageWaitTime.size());
//
//            if (averageWaitTime == null || averageWaitTime.size() == 0) {
//                logger.info("时刻表mapping中有" + timetableVersion + ",但是数据表中没有该数据,需要找最邻近日期的版本");
//
//                Date theDayBeforeDateNow = findNearDateType(timeNow);
//                logger.info("最邻近日期:" + theDayBeforeDateNow);
//
//                timetableVersion = gzdt_553.findTimeTableVersion(getForDate(theDayBeforeDateNow), "user");
////                List<String> averageWaitTime2 = gzdt_553.findODAverageWaitTime(oStationCode, dStationCode, timetableVersion);
//                if (timetableVersion==null||timetableVersion.equals("")){
//                    logger.info("时刻表中最邻近日期的版本为空");
////                timetableVersion="default";
//                    List<String> averageWaitTimeDefault = gzdt_553.findODAverageWaitTime("default");
//
//                    if (averageWaitTimeDefault == null || averageWaitTimeDefault.size() == 0) {
//                        logger.info("没有default对应的数据");
//                        timetableVersion = null;
//                    }
//                }else {
//                    List<String> averageWaitTimeLast = gzdt_553.findODAverageWaitTime(timetableVersion);
//
//                    if (averageWaitTimeLast == null || averageWaitTimeLast.size() == 0) {
//                        logger.info("时刻表mapping中有" + timetableVersion + ",但是数据表中没有该数据");
//
//                        List<String> averageWaitTimeDefault = gzdt_553.findODAverageWaitTime("default");
//
//                        if (averageWaitTimeDefault == null || averageWaitTimeDefault.size() == 0) {
//                            logger.info("没有default对应的数据");
//                            timetableVersion = null;
//                        }
//                    }
//                }
////                List<String> averageWaitTime2 = gzdt_553.findODAverageWaitTime(timetableVersion);
////
//////                logger.info( timetableVersion + ",averageWaitTime2.size():" + averageWaitTime2.size());
////
////                if (averageWaitTime2 == null || averageWaitTime2.size() == 0) {
////                    logger.info("时刻表mapping中有" + timetableVersion + ",但是数据表中没有该数据");
////                    timetableVersion = null;
////                }
//            }
//        }
//
//        logger.info("timetableVersion: " + timetableVersion);
//
//        return timetableVersion;
//    }


    /**
     * 剔除o或者d为换乘站出现重复的情况
     *
     * @param
     * @return
     */
    private deleteRepetitiveStationResult deleteRepetitiveStation(List<String> stationList, String dataVersion, String oStationCode, String OtransStationCode, String dStationCode, String DtransStationCode) {
        deleteRepetitiveStationResult result = new deleteRepetitiveStationResult();
        if (gzdt_553.findStationName(stationList.get(0), dataVersion, "user").get(0).getStation_name().equals(gzdt_553.findStationName(stationList.get(1), dataVersion, "user").get(0).getStation_name())) {
            logger.info("前后站名相同，O站是换乘站");
            oStationCode = stationList.get(1);
            OtransStationCode = stationList.get(0);
            stationList.remove(0);
        }
        if (gzdt_553.findStationName(stationList.get(stationList.size() - 1), dataVersion, "user").get(0).getStation_name().equals(gzdt_553.findStationName(stationList.get(stationList.size() - 2), dataVersion, "user").get(0).getStation_name())) {
            logger.info("前后站名相同，D站是换乘站");
            dStationCode = stationList.get(stationList.size() - 2);
            DtransStationCode = stationList.get(stationList.size() - 1);
            stationList.remove(stationList.size() - 1);
        }
        result.setoStationCode(oStationCode);
        result.setOtransStationCode(OtransStationCode);
        result.setdStationCode(dStationCode);
        result.setDtransStationCode(DtransStationCode);
        result.setStationList(stationList);

        return result;
    }

    /**
     * 打标签
     *
     * @param
     * @return
     */
    private List<String> setTypes(gzdt_553 gzdt_5531, double overallbest, Integer timeleast, Integer transferLeast, Integer waitLeast, double loadmin) throws ParseException {

        List<String> types = new ArrayList();
        String recoType = "";//添加推荐类型
        int typeValue = 0;

        if (Objects.equals(gzdt_5531.getV_logit(), overallbest)) {
            recoType += "overall-";

        }

        if (Objects.equals(gzdt_5531.getTotal_time(), timeleast)) recoType += "times-";
        if (Objects.equals(gzdt_5531.getTrans_amount(), transferLeast)) recoType += "trans-";
        if (Objects.equals(gzdt_5531.getWait_time(), waitLeast)) recoType += "wait-";
        if (loadmin != 2) {
            if (Objects.equals(gzdt_5531.getLoad_rate(), loadmin)) recoType += "load-";
        }
        //typeValue表示有几个标签值
        //        if (recoType.length() != 0) {

        //            typeValue = recoType.split("-").length;
        if (gzdt_5531.isInfluence() == true) {

            recoType += "event-";
            //                typeValue = -recoType.split("-").length;
        }
        //        }

        types.add(recoType);
        //        types.add(String.valueOf(typeValue));

        return types;
    }


    private List<OdPathResponseData> sortOdPathResponseDataList(List<OdPathResponseData> odPathResponseDataList) {

        Collections.sort(odPathResponseDataList, new Comparator<OdPathResponseData>() {
            public int compare(OdPathResponseData o1, OdPathResponseData o2) {


                if (null == o1.getLogitValue()) {
                    return -1;
                }
                if (null == o1.getLogitValue()) {
                    return 1;
                }
                return o1.getLogitValue().compareTo(o2.getLogitValue());//升序
            }
        });

        return odPathResponseDataList;
    }


    /**
     * 排序
     *
     * @param
     * @return
     */
    private List<JSONObject> sortList(List<JSONObject> jsonArray) {

        Collections.sort(jsonArray, new Comparator<JSONObject>() {
            public int compare(JSONObject o1, JSONObject o2) {

                OdPathResponseData odPathResponseData = JSONObject.toJavaObject(o1, OdPathResponseData.class);
                OdPathResponseData odPathResponseData2 = JSONObject.toJavaObject(o2, OdPathResponseData.class);
                if (null == odPathResponseData.getLogitValue()) {
                    return -1;
                }
                if (null == odPathResponseData.getLogitValue()) {
                    return 1;
                }
                return odPathResponseData.getLogitValue().compareTo(odPathResponseData2.getLogitValue());//升序
                //                return o2.getTypeValue().compareTo(o1.getTypeValue());//降序
            }
        });

        return jsonArray;
    }


    private List<OdPathResponseData> sortListByMultPas(List<OdPathResponseData> odPathResponseData) {

        Collections.sort(odPathResponseData, new Comparator<OdPathResponseData>() {

            public int compare(OdPathResponseData o1, OdPathResponseData o2) {

                if (o1.getFirstValue() < o2.getFirstValue()) {//  一级类目
                    return -1;
                } else if (o1.getFirstValue().equals(o2.getFirstValue())) {    //  一级类目相同
                    if (o1.getSecondValue() < o2.getSecondValue()) {
                        return -1;
                    } else if (o1.getSecondValue().equals(o2.getSecondValue())) {    //  二级类目相同
                        if (o1.getThirdValue() < o2.getThirdValue()) {  //  三级类目
                            return -1;
                        } else if (o1.getThirdValue().equals(o2.getThirdValue())) {//  三级类目相同
                            if (o1.getLogitValue() < o2.getLogitValue()) {  //  四级类目
                                return -1;
                            } else if (o1.getLogitValue().equals(o2.getLogitValue())) {//  四级类目相同
                                return 0;
                            } else {
                                return 1;
                            }
                        } else {
                            return 1;
                        }
                    } else {
                        return 1;
                    }
                } else {
                    return 1;
                }
            }
        });


        return odPathResponseData;
    }


    /**
     * 常态限流
     *
     * @param
     * @return
     */
    private NormalStationLimit normalLimit(NormalStationLimit normalStationLimit, gzdt_553 ARecordNormalLimit, Date timeNow, Integer waitTime) {

        Integer minDelayTime = ARecordNormalLimit.getMin_delay_time();
        Integer maxDelayTime = ARecordNormalLimit.getMax_delay_time();
        Integer delay_time = (minDelayTime + maxDelayTime) / 2;

        timeNow.setTime(timeNow.getTime() + delay_time * 1000);
        waitTime += delay_time;

        normalStationLimit.setTimeNow(timeNow);
        normalStationLimit.setWaitTime(waitTime);
        normalStationLimit.setMinDelayTime(minDelayTime + normalStationLimit.getMinDelayTime());
        normalStationLimit.setMaxDelayTime(maxDelayTime + normalStationLimit.getMaxDelayTime());

        return normalStationLimit;
    }

    private NormalStationLimit JudgeOneNormalStationLimit(Integer day_type, Integer week_day, List<gzdt_553> normalLimitList, int i, NormalStationLimit normalStationLimit, Date timeNow, Integer waitTime) {

        if (day_type == 4 || day_type == 1) {
            if (week_day == 6 || week_day == 7) {
                //周六或日为工作日或者节假日前一天时需要特殊处理
                //如果1-5都控了，那么6、7也控

                if (normalLimitList.get(i).getWeek_days().length() > 8) {
                    if (Objects.equals(normalLimitList.get(i).getWeek_days().substring(0, 9), "1,2,3,4,5")) {
                        normalStationLimit = normalLimit(normalStationLimit, normalLimitList.get(i), timeNow, waitTime);

                    }
                }

            } else {
                //周一-五
                String[] WeekDays = normalLimitList.get(i).getWeek_days().split(",");//根据分隔符将各车站拆串
                for (String weekDay : WeekDays) {
                    if (Objects.equals(dateToWeek(timeNow), weekDay)) {
                        normalStationLimit = normalLimit(normalStationLimit, normalLimitList.get(i), timeNow, waitTime);

                    }
                }
            }
        }

        if (day_type == 3 && Objects.equals(normalLimitList.get(i).getWeek_days(), "1,2,3,4,5,6,7")) {

            logger.info("节假日");
            //如果1-7都控了，那么节假日也控
            normalStationLimit = normalLimit(normalStationLimit, normalLimitList.get(i), timeNow, waitTime);

        }

        if (day_type == 2) {
            String[] WeekDays = normalLimitList.get(i).getWeek_days().split(",");//根据分隔符将各车站拆串
            for (String weekDay : WeekDays) {
                if (Objects.equals(dateToWeek(timeNow), weekDay)) {
                    normalStationLimit = normalLimit(normalStationLimit, normalLimitList.get(i), timeNow, waitTime);

                }
            }
        }

        return normalStationLimit;
    }

    /**
     * 常态进站限流
     *
     * @param
     * @return
     */
    //常态进站限流getEventNormalEntranceStationLimit
    private NormalStationLimit getNormalEntranceLimit(String oStationCode, String dStationCode, String LineAfcCode, String departTimeget, Date timeNow, Integer waitTime, List<String> stationCodeList) throws ParseException {
        NormalStationLimit normalStationLimit = new NormalStationLimit();

        normalStationLimit.setMaxDelayTime(0);
        normalStationLimit.setMinDelayTime(0);
        normalStationLimit.setWaitTime(waitTime);
        normalStationLimit.setTimeNow(timeNow);

        String param_code = "VER_NOR_LIMIT";//VER_STATION_LIMIT
        String dataVersion = gzdt_553.findDataVersion(param_code).getParam_value();

        //同一站存在多级别，只有1级有备注
        List<gzdt_553> normalLimitList = new ArrayList<>();

        //换乘站有多个车站编码
        for (int i = 0; i < stationCodeList.size(); i++) {

            normalLimitList.addAll(gzdt_553.findNormalLimitByOTime(stationCodeList.get(i), getDataToFormatString(timeNow, "HH:mm"), dataVersion, "user"));//获取常态进站限流延误，取后六位

        }

        logger.info(oStationCode + "normalLimitList.size():" + normalLimitList.size() + "，限流版本：" + dataVersion + "getDataToFormatString(timeNow, \"HH:mm\")" + getDataToFormatString(timeNow, "HH:mm"));

        //区间的版本号
        param_code = "VER_NET_PARAM";
        String version_code = gzdt_553.findDataVersion(param_code).getParam_value();


        Integer day_type = gzdt_553.findDataTypeWeekDay(getForDate(timeNow), "user").getDay_type();
        Integer week_day = gzdt_553.findDataTypeWeekDay(getForDate(timeNow), "user").getWeek_day();

        if (normalLimitList.size() != 0) {

            logger.info("normalLimit.size():" + normalLimitList.size());
            //多级叠加
            for (int i = 0; i < normalLimitList.size(); i++) {
                //1级有方向
                if (normalLimitList.get(i).getStation_limit_level().equals("1")) {
                    //解析备注
                    String[] eventComment = normalLimitList.get(i).getEvent_comment().split("；");
                    for (int j = 0; j < eventComment.length; j++) {
                        String[] commentDetail = eventComment[j].split("#");

                        //2为进站，3为换乘
                        if (commentDetail.length == 2) {

                            //判断线路名，如体育西路对应两条线
                            if (commentDetail[0].equals(LineAfcCode)) {
                                if (commentDetail[1].equals("01")) {//上下行
                                    logger.info("上下行均有进站限流");

                                    //'日期类型；1-工作日；2-周末；3-节假日；4-节假日前一天',
                                    //受影响时间
                                    //调休,1-5全控调休也控

                                    normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimitList, i, normalStationLimit, timeNow, waitTime);

                                } else if (commentDetail[1].equals("0")) {//上行
                                    logger.info("上行有进站限流");
                                    String up_down = "0";
                                    //版本号+ocode+up_down查d,d一致才受影响

                                    gzdt_553 dCode = gzdt_553.findSectionDStationCode(oStationCode, up_down, version_code, "user");
                                    if (dCode.getD_station_code().equals(dStationCode)) {

                                        //受影响时间
                                        //调休,1-5全控调休也控
                                        normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimitList, i, normalStationLimit, timeNow, waitTime);


                                    } else {
                                        logger.info("不受影响");
                                    }

                                } else {
                                    logger.info("下行有进站限流");
                                    String up_down = "1";
                                    //版本号+ocode+up_down查d,d一致才受影响
                                    gzdt_553 dCode = gzdt_553.findSectionDStationCode(oStationCode, up_down, version_code, "user");
                                    logger.info("dCode: " + dCode);
                                    if (dCode.getD_station_code().equals(dStationCode)) {

                                        //受影响时间
                                        //调休,1-5全控调休也控
                                        normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimitList, i, normalStationLimit, timeNow, waitTime);


                                    } else {
                                        logger.info("不受影响");
                                    }

                                }

                            } else {
                                logger.info("所控制线路不是路径线路");
                            }

                        } else {
                            logger.info("不是进站限流");
                        }
                    }

                } else {
                    //除了1级其他都是只要有就加 没有方向问题
                    //受影响时间
                    //调休,1-5全控调休也控
                    //二三级客控不控换乘只控进站

                    normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimitList, i, normalStationLimit, timeNow, waitTime);


                }
            }

        } else {
            logger.info("当前站无常态限流");
        }


        return normalStationLimit;
    }

    /**
     * 常态换乘限流
     *
     * @param
     * @return
     */
    //getEventNormalTransferStationLimit
    //常态换乘限流,String oS, Date timeNow, Integer totalTime, Integer waitTime, String transStationCode, String transLineName
    private NormalStationLimit getNormalLimit(String oS, String dS, String LineAfcCode, Date timeNow, Integer waitTime, String transStationCode, String transLineAfcCode) throws ParseException {
        NormalStationLimit normalStationLimit = new NormalStationLimit();

        normalStationLimit.setMaxDelayTime(0);
        normalStationLimit.setMinDelayTime(0);
        normalStationLimit.setWaitTime(waitTime);
        normalStationLimit.setTimeNow(timeNow);

        String param_code = "VER_NOR_LIMIT";//VER_STATION_LIMIT
        String dataVersion = gzdt_553.findDataVersion(param_code).getParam_value();

        //同一站存在多级别，只有1级有备注
        List<gzdt_553> normalLimit = gzdt_553.findNormalLimitByOTime(oS, getDataToFormatString(timeNow, "HH:mm"), dataVersion, "user");//获取常态进站限流延误，取后六位

        List<gzdt_553> normalLimit2 = gzdt_553.findNormalLimitByOTime(transStationCode, getDataToFormatString(timeNow, "HH:mm"), dataVersion, "user");//获取常态进站限流延误，取后六位

        if (normalLimit2.size() != 0) {
            normalLimit.addAll(normalLimit2);
        }
        //区间的版本号
        param_code = "VER_NET_PARAM";
        String version_code = gzdt_553.findDataVersion(param_code).getParam_value();

        logger.info(oS + "/" + transStationCode + "normalLimit.size():" + normalLimit.size() + "限流版本：" + dataVersion + "getDataToFormatString(timeNow, \"HH:mm\")" + getDataToFormatString(timeNow, "HH:mm"));

        Integer day_type = gzdt_553.findDataTypeWeekDay(getForDate(timeNow), "user").getDay_type();
        Integer week_day = gzdt_553.findDataTypeWeekDay(getForDate(timeNow), "user").getWeek_day();


        if (normalLimit.size() != 0) {

            logger.info("normalLimit.size():" + normalLimit.size());
            //换乘只有一级限流因此没有多级叠加的问题
            for (int i = 0; i < normalLimit.size(); i++) {
                //1级有方向
                if (normalLimit.get(i).getStation_limit_level().equals("1")) {
                    //解析备注
                    String[] eventComment = normalLimit.get(i).getEvent_comment().split("；");

                    for (int j = 0; j < eventComment.length; j++) {
                        String[] commentDetail = eventComment[j].split("#");
                        //判断当前站需要换乘
                        if (transStationCode != null) {

                            //2为进站，3为换乘
                            if (commentDetail.length == 3) {

                                //判断线路名，如体育西路对应两条线
                                //换乘限流前后两条线路都受影响
                                if (commentDetail[1].equals(LineAfcCode) && commentDetail[0].equals(transLineAfcCode)) {
                                    if (commentDetail[2].equals("01")) {//上下行
                                        logger.info("上下行均有换乘限流");
                                        //受影响时间
                                        //调休,1-5全控调休也控
                                        normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimit, i, normalStationLimit, timeNow, waitTime);


                                    } else if (commentDetail[2].equals("0")) {//上行
                                        logger.info("上行有换乘限流");
                                        String up_down = "0";
                                        //版本号+ocode+up_down查d,d一致才受影响

                                        gzdt_553 dCode = gzdt_553.findSectionDStationCode(oS, up_down, version_code, "user");
                                        if (dCode.getD_station_code().equals(dS)) {

                                            //受影响时间
                                            //调休,1-5全控调休也控
                                            normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimit, i, normalStationLimit, timeNow, waitTime);


                                        } else {
                                            logger.info("不受影响");
                                        }

                                    } else {
                                        logger.info("下行有换乘限流");
                                        String up_down = "1";
                                        //版本号+ocode+up_down查d,d一致才受影响
                                        gzdt_553 dCode = gzdt_553.findSectionDStationCode(oS, up_down, version_code, "user");
                                        if (dCode.getD_station_code().equals(dS)) {

                                            //受影响时间
                                            //调休,1-5全控调休也控
                                            normalStationLimit = JudgeOneNormalStationLimit(day_type, week_day, normalLimit, i, normalStationLimit, timeNow, waitTime);


                                        } else {
                                            logger.info("不受影响");
                                        }
                                    }
                                } else {
                                    logger.info("所控制线路不是路径线路");
                                }

                            } else {
                                logger.info("不是换乘限流");
                            }

                        } else {
                            logger.info("当前站不需要换乘");
                        }
                    }
                }
            }

        } else {
            logger.info("当前站无常态限流");
        }

        return normalStationLimit;
    }


    /**
     * 处理突发
     *
     * @param
     * @return
     */
    private EventInfluence getEventInfluence(Date timeNow, String transStationCode, gzdt_553 gzdt_5531, String oStationCode, String dStationCode, String oD, String oS, String OtransStationCode, String DtransStationCode, String beforeTransStationCode, String overrun_up_down, String overrun_beforeOs_transStationCode, Date systemDateNow, String transLineAfcCode, String lineAfcCode) {

        EventInfluence eventInfluence = new EventInfluence();
        boolean eventPassengerFlowControl = false;
        boolean overrun = false;
        boolean delaysOrInterruptions = false;
        String overrunOCode = "";
        String overrunDirection = "";
        String overrunLineAfcCode = "";
        String eventEmergencyOSCode = null;
        String eventEmergencyDSCode = null;
        String eventEmergencyLineAfcCode = null;

        List<EventInfluenceData> delayEvent1 = gzdt_553.findDelayByDate(timeNow, "user", systemDateNow);

        if (delayEvent1.size() != 0) {
            for (EventInfluenceData eventInfluenceData : delayEvent1) {
                //event_type里面是1-车站客控；2-突发事件；limit_type分情况，如果是突发的话，1-中断 2-延误 3-越行，如果是站控的话是1-一级站控、2-二级站控、3-三级站控
                //越行,event_type=2&&limit_type=3
                if (eventInfluenceData.getEvent_type().equals("2") && eventInfluenceData.getLimit_type() == 3) {
                    //越行只判断od和换乘站是否受影响
                    if (transStationCode != null) {
                        if ((transStationCode.equals(eventInfluenceData.getO_station_code()) && overrun_beforeOs_transStationCode.equals(eventInfluenceData.getUp_down())) || (oS.equals(eventInfluenceData.getO_station_code()) && overrun_up_down.equals(eventInfluenceData.getUp_down()))) {
                            gzdt_5531.setSectionEventInfluence(true);
                            overrun = true;
                            overrunOCode = eventInfluenceData.getO_station_code();
                            overrunDirection = eventInfluenceData.getUp_down();
                            overrunLineAfcCode = eventInfluenceData.getO_line_afc_code();
                            logger.info("换乘站受越行影响");
                        }
                    } else {
                        //当前站不是中间的换乘站,判断是否为始发、终到站
                        if (oS.equals(oStationCode)) {
                            logger.info("overrun_up_down0:" + overrun_up_down);
                            if (oS.equals(eventInfluenceData.getO_station_code()) && overrun_up_down.equals(eventInfluenceData.getUp_down())) {
                                gzdt_5531.setSectionEventInfluence(true);
                                overrun = true;
                                //漏加了
                                overrunOCode = eventInfluenceData.getO_station_code();
                                overrunDirection = eventInfluenceData.getUp_down();
                                overrunLineAfcCode = eventInfluenceData.getO_line_afc_code();
                            }
                        } else if (oS.equals(dStationCode)) {
                            //判断当前终到站是否是换乘站
                            if (oS.equals(eventInfluenceData.getO_station_code()) && overrun_up_down.equals(eventInfluenceData.getUp_down())) {
                                gzdt_5531.setSectionEventInfluence(true);
                                overrun = true;
                                //漏加了
                                overrunOCode = eventInfluenceData.getO_station_code();
                                overrunDirection = eventInfluenceData.getUp_down();
                                overrunLineAfcCode = eventInfluenceData.getO_line_afc_code();

                            }

                        }
                    }
                } else if (eventInfluenceData.getEvent_type().equals("1")) {
                    //1级人工输入有方向，其他均不分方向
                    //处理突发客控(od为同一站)，进站o和换乘站是否受影响
                    //换乘站
                    if (transStationCode != null) {
                        if (eventInfluenceData.getLimit_type() == 1) {
                            if (eventInfluenceData.getUp_down() != null) {
                                //人工接入有方向
                                if (transStationCode.equals(eventInfluenceData.getO_station_code()) && transLineAfcCode.equals(eventInfluenceData.getO_line_afc_code()) && oS.equals(eventInfluenceData.getD_station_code()) && lineAfcCode.equals(eventInfluenceData.getD_line_afc_code())) {
                                    if (eventInfluenceData.getUp_down().equals("2")) {

                                        gzdt_5531.setSectionEventInfluence(true);
                                        eventPassengerFlowControl = true;
                                    } else if (overrun_up_down.equals(eventInfluenceData.getUp_down())) {
                                        //人工接入换乘站控
                                        gzdt_5531.setSectionEventInfluence(true);
                                        eventPassengerFlowControl = true;
                                    }
                                }
                            } else {
                                //人工接入无备注或者接口接入
                                if (Objects.equals(eventInfluenceData.getO_station_code(), transStationCode) || Objects.equals(eventInfluenceData.getO_station_code(), oS)) {
                                    gzdt_5531.setSectionEventInfluence(true);
                                    eventPassengerFlowControl = true;
                                }
                            }
                        } else {
                            logger.info("二三级站控不控换乘");
                        }
                    } else {
                        //当前站不是换乘站,判断是否为始发站
                        //判断始发站属性是否是换乘站
                        if (oS.equals(oStationCode)) {
                            if (eventInfluenceData.getUp_down() != null) {
                                //人工接入有方向
                                //人工接入1级站控，区分方向
                                if (oStationCode.equals(eventInfluenceData.getO_station_code()) && lineAfcCode.equals(eventInfluenceData.getO_line_afc_code()) && eventInfluenceData.getO_station_code().equals(eventInfluenceData.getD_station_code())) {
                                    if (eventInfluenceData.getUp_down().equals("2")) {
                                        //人工接入进站站控
                                        gzdt_5531.setSectionEventInfluence(true);
                                        eventPassengerFlowControl = true;
                                    } else if (eventInfluenceData.getUp_down().equals(overrun_up_down)) {
                                        //人工接入进站站控
                                        gzdt_5531.setSectionEventInfluence(true);
                                        eventPassengerFlowControl = true;
                                    }
                                }
                            } else {
                                //人工接入无备注或者接口接入
                                if ((Objects.equals(eventInfluenceData.getO_station_code(), oS)) || (OtransStationCode.equals(eventInfluenceData.getO_station_code()))) {
                                    gzdt_5531.setSectionEventInfluence(true);
                                    eventPassengerFlowControl = true;
                                }
                            }
                        }
                    }

                } else if (eventInfluenceData.getEvent_type().equals("2") && (eventInfluenceData.getLimit_type() == 1 || eventInfluenceData.getLimit_type() == 2)) {
                    //处理2突发中1中断或2延误,经过即受影响
                    if (oS.equals(eventInfluenceData.getO_station_code()) && Objects.equals(eventInfluenceData.getD_station_code(), oD)) {
                        gzdt_5531.setSectionEventInfluence(true);
                        delaysOrInterruptions = true;
                        EventEmergency eventEmergency = eventEmergencyService.findByRecordId(eventInfluenceData.getEvent_record_id());
                        eventEmergencyOSCode = eventEmergency.getO_station_code();
                        eventEmergencyDSCode = eventEmergency.getD_station_code();
                        eventEmergencyLineAfcCode = eventEmergency.getLine_afc_code();
                    }
                }
            }
        }
        eventInfluence.setDelaysOrInterruptions(delaysOrInterruptions);
        eventInfluence.setEventPassengerFlowControl(eventPassengerFlowControl);
        eventInfluence.setOverrun(overrun);
        eventInfluence.setOverrunOCode(overrunOCode);
        eventInfluence.setOverrunDirection(overrunDirection);
        eventInfluence.setOverrunLineAfcCode(overrunLineAfcCode);
        eventInfluence.setEventEmergencyOSCode(eventEmergencyOSCode);
        eventInfluence.setEventEmergencyDSCode(eventEmergencyDSCode);
        eventInfluence.setEventEmergencyLineAfcCode(eventEmergencyLineAfcCode);
        return eventInfluence;
    }

    /**
     * 获取满载率list
     *
     * @param oS      区间出发
     * @param oD      区间到达
     * @param timeNow 出发时间
     * @param shike   小时时刻：091
     * @return 满载率List
     * @throws ParseException
     */
    private List<gzdt_553> getLoadRate(String oS, String oD, Date timeNow, String shike) throws ParseException {

        timeNow = getForDate(timeNow);
        int dayType;
        int weekDay;
        List<gzdt_553> dataTypeWeekDay = new ArrayList<>();
        dataTypeWeekDay.add(gzdt_553.findDataTypeWeekDay(timeNow, "user"));
        if (dataTypeWeekDay.size() != 0) {
            dayType = dataTypeWeekDay.get(0).getDay_type();
            weekDay = dataTypeWeekDay.get(0).getWeek_day();
        } else {
            dayType = 0;
            weekDay = 0;
        }
        //        //日期类型；1-工作日；2-周末；3-节假日；4-节假日前一天'
        //        if (dayType == 3) {
        //            weekDay = 1;
        //        } else if (dayType == 4) {
        //            weekDay = 1;
        //        }

        //找到当前LOAD_SEC的版本号
        String param_code = "VER_LOAD_SEC";
        gzdt_553 runVersion = gzdt_553.findDataVersion(param_code);
        String dataVersion = runVersion.getParam_value();

        List<gzdt_553> loadRate;
        if (runVersion.getParam_value() != null) {
            loadRate = gzdt_553.findChaRateByDayTypeWeekDay(oS, oD, dayType, weekDay, shike, dataVersion, "user");

            if (loadRate.size() == 0) {
                logger.info(oS + "-" + oD + "区间,base_sec_rate_character中无当前" + dataVersion + "版本号对应的数据");

                //                logger.info("没有所选日期的特征满载率数据,应找到最邻近日期的数据");

                //                //无时刻表查询日期的数据，查找最邻近的同类型日期数据
                //                Date theDayBeforeDateNow = calculateNearDateType(timeNow);
                //
                //                String HHmm = getDataToFormatString(timeNow, "HH:mm");
                //                loadRate = getHisLoadRate(oS, oD, theDayBeforeDateNow, HHmm, shike);


            }

        } else {
            loadRate = null;
            logger.info("param_runtime缺少当前loadSec的版本号");
        }

        return loadRate;
    }

//    private List<gzdt_553> getHisLoadRate(String oS, String oD, Date timeNow, String shike, String HHmmss) throws ParseException {
//
//        timeNow = getForDate(timeNow);
//
//        String stringTime = getDataToFormatString(timeNow, "yyyy-MM-dd");
//        List<gzdt_553> loadRate;
//        loadRate = gzdt_553.findHisRateByDate(oS, oD, shike, stringTime, "user");
//        if (loadRate.size() == 0) {
//            logger.info("base_sec_rate_his中无当前日期的数据，使用特征满载率");
//            loadRate = getLoadRate(oS, oD, timeNow, HHmmss);
//        }
//
//        return loadRate;
//    }

    private List<gzdt_553> getHisLoadRate(String oS, String oD, Date timeNow, String shike, String HHmmss) throws ParseException {

        timeNow = getForDate(timeNow);

        String stringTime = getDataToFormatString(timeNow, "yyyy-MM-dd");
        List<gzdt_553> loadRate;
        loadRate = gzdt_553.findHisRateByDate(oS, oD, shike, stringTime, "user");
        if (loadRate.size() == 0) {
            logger.info("base_sec_rate_his中无当前日期的数据，使用特征满载率");
            loadRate = getLoadRate(oS, oD, timeNow, HHmmss);
        }

        return loadRate;
    }

    /**
     * Date转化为指定格式的字符串
     *
     * @param time 出发时间
     * @return 指定格式的字符串
     */

    private static String getDataToFormatString(Date time, String DateFormat) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DateFormat);
        return sdf.format(time);
    }

    /**
     * 时间数据保留日期
     *
     * @param time 完整时间
     * @return 日期
     * @throws ParseException
     */
    private static Date getFormatDate(String time, String DateFormat) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DateFormat);
        return sdf.parse(time);
    }

    private static Date getForDate(Date time) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.parse(sdf.format(time));
    }

    private static Date getDateTime(String time) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.parse(time);
    }


    /**
     * 计算Logit效用
     *
     * @return V_logit
     */
    private static double logit(double trans_coef, double trans_count_coef, double trafic_jam_one, double trafic_jam_two, Integer RunTime, double comfort, Integer transCont, Integer transWaitTime, Integer transWalkTime) {
        Double logitValue;

        //换乘惩罚系数*换乘总次数^换乘次数惩罚系数(总换乘走行+总换乘候车时间)
        Double transPart = trans_coef * Math.pow(transCont, trans_count_coef) * (transWaitTime + transWalkTime);//总换乘候车时间+总换乘走行时间
        //换乘惩罚系数*换乘总次数^换乘次数惩罚系数(总换乘走行+总换乘候车时间)
        //计算C舒适度
        Double C;
        if (comfort <= 80) {
            C = 0.0;
        } else if (comfort >= 100) {
            C = 1 + trafic_jam_one * 0.2 + trafic_jam_two * (comfort - 1);
        } else {
            C = 1 + trafic_jam_one * 0.2;
        }


        //（1+舒适度）*（总区间运行+总在站停留时间）
        Double runPart = (1 + C) * RunTime;//RunTime总区间运行和在站停留时间
        logitValue = transPart + runPart;

        return logitValue;
    }

    /**
     * 输入日期获取具体星期
     *
     * @param datetime 日期时间
     * @return 星期
     */
    private static String dateToWeek(Date datetime) {

        String[] weekDays = {"7", "1", "2", "3", "4", "5", "6"};
        Calendar cal = Calendar.getInstance();
        cal.setTime(datetime);
        //一周的第几天
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) w = 0;
        return weekDays[w];
    }

    //获取历史满载率颜色
    private String getLoadRateColor(Double Load_rate) {
        String Load_rate_color = null;
        List<ParamLoadRate> ParamLoadRates = gzdt_553.findParamLoadRate();
        for (ParamLoadRate paramLoadRate : ParamLoadRates) {
            //判断是否有上限
            if (paramLoadRate.getUp_code() == 0) {

                if (Load_rate >= paramLoadRate.getDown_code()) {
                    Load_rate_color = paramLoadRate.getColor_code();
                }
            } else {

                if (Load_rate >= paramLoadRate.getDown_code() && Load_rate < paramLoadRate.getUp_code()) {
                    Load_rate_color = paramLoadRate.getColor_code();
                }
            }

        }

        return Load_rate_color;
    }

    //获取历史满载率等级
    private int getLoadRateLevel(Double Load_rate) {
        int level = 0;
        List<ParamLoadRate> ParamLoadRates = gzdt_553.findParamLoadRate();
        for (int i = 0; i < ParamLoadRates.size(); i++) {
            if (ParamLoadRates.get(i).getUp_code() == 0) {
                if (Load_rate >= ParamLoadRates.get(i).getDown_code()) {
                    level = 4;
                }
            } else {
                if (Load_rate >= ParamLoadRates.get(i).getDown_code() && Load_rate < ParamLoadRates.get(i).getUp_code()) {
                    level = i + 1;
                }
            }

        }

        return level;
    }

    //获取历史满载率所有颜色
    private String getAllLoadRateColor() {

        List<ParamLoadRate> ParamLoadRates = gzdt_553.findParamLoadRate();

        StringBuilder stringBuilder = new StringBuilder();

        for (ParamLoadRate paramLoadRate : ParamLoadRates) {
            stringBuilder.append(paramLoadRate.getColor_code() + "-");
        }
        return stringBuilder.toString();
    }

    private String findOdPathLastTimeVersion(Date departTime, String oStationCode, String dStationCode) throws ParseException {

        //末班车
        gzdt_553 mbcDataVersion;
        Date calendar_day = getForDate(departTime);
        //        logger.info("calendar_day: " + calendar_day);
        mbcDataVersion = gzdt_553.findOdLastVersion(calendar_day, "user");
        String MBCdataVersion;
        if (mbcDataVersion != null) {
            //有版本不一定有数据
            //接下来判断是不是有数据


            MBCdataVersion = mbcDataVersion.getData_version();
            List<BaseOdPathLast> OdFinalTime = gzdt_553.findOdFinalTime(MBCdataVersion, oStationCode, dStationCode);
            if (OdFinalTime == null || OdFinalTime.size() == 0) {
                logger.info("mapping中有" + MBCdataVersion + ",但是数据表中没有数据，需要找最邻近日期");

                Date theDayBeforeDateNow = findNearDateType(departTime);

                mbcDataVersion = gzdt_553.findOdLastVersion(theDayBeforeDateNow, "user");
                if (mbcDataVersion == null) {
                    MBCdataVersion = "default";
                    logger.info("没有找到今日和最临近日期类型的末班车的数据版本！采用默认版本数据！");
                } else {
                    MBCdataVersion = mbcDataVersion.getData_version();
                    List<BaseOdPathLast> OdFinalTime2 = gzdt_553.findOdFinalTime(MBCdataVersion, oStationCode, dStationCode);

                    if (OdFinalTime2 == null || OdFinalTime2.size() == 0) {
                        logger.info("mapping中有" + MBCdataVersion + ",但是数据表中没有数据，需要找默认版本数据");
                        MBCdataVersion = "default";
                        logger.info("没有找到今日和最临近日期类型的末班车的数据版本！采用默认版本数据！");
                    }

                }

            }

        } else {

            //            Date theDayBeforeDateNow = calculateNearDateType(departTime);
            Date theDayBeforeDateNow = findNearDateType(departTime);

            mbcDataVersion = gzdt_553.findOdLastVersion(theDayBeforeDateNow, "user");
            if (mbcDataVersion == null) {
                MBCdataVersion = "default";
                logger.info("没有找到今日和最临近日期类型的末班车的数据版本！采用默认版本数据！");
            } else {
                MBCdataVersion = mbcDataVersion.getData_version();

                List<BaseOdPathLast> OdFinalTime2 = gzdt_553.findOdFinalTime(MBCdataVersion, oStationCode, dStationCode);

                if (OdFinalTime2 == null || OdFinalTime2.size() == 0) {
                    logger.info("mapping中有" + MBCdataVersion + ",但是数据表中没有数据，需要找默认版本数据");
                    MBCdataVersion = "default";
                    logger.info("没有找到今日和最临近日期类型的末班车的数据版本！采用默认版本数据！");
                }

            }

        }

        //        logger.info("MBCdataVersion:" + MBCdataVersion);
        return MBCdataVersion;
    }


    public static Date DateMinus1(Date date, String dataStandard, int i) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dataStandard);//设置日期格式,"yyyy-MM-dd HH:mm:ss"

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        //获取当前时间前一天的日期
        calendar.add(Calendar.DATE, i);
        date = calendar.getTime();
        String formatData = simpleDateFormat.format(date);
        return simpleDateFormat.parse(formatData);
    }


    public Date findNearDateType(Date timeNow) throws ParseException {
        //无时刻表查询日期的数据，查找最邻近的同类型日期数据

        Date theDayBeforeDateNow = new Date();
        //        Date theDayBeforeDateNow = DateMinus1(timeNow, "yyyy-MM-dd", -7);

        //        System.out.println("theDayBeforeDateNow: " + theDayBeforeDateNow);
        //        String DataType = gzdt_553.findDataType(getForDate(timeNow), "user");

        Integer weekDay = gzdt_553.findDataTypeWeekDay(getForDate(timeNow), "user").getWeek_day();
        Integer DataType = gzdt_553.findDataTypeWeekDay(getForDate(timeNow), "user").getDay_type();

        //找到符合要求的最近邻日期

        List<Date> CalendarDayList = paramCalendarService.findCalendarDayList(DataType, weekDay, getForDate(timeNow));


        if (CalendarDayList.size() != 0) {
//            logger.info("CalendarDayList.get(0)" + CalendarDayList.get(0));
            theDayBeforeDateNow = CalendarDayList.get(0);
        }


        return theDayBeforeDateNow;
    }

    public void calculatePath(String path_station, String param_code, String oStationCode, String dStationCode, String strid, boolean ifNeedBeforeDate, Date timeNow, Date theDayBeforeYesterdayDateNow, Date departTime, gzdt_553 gzdt_5531, Integer totalTime, Integer totalWaitTime, Integer totalWalkTime, List<gzdt_553> finalPaths, Date systemDateNow, String timetableVersion) throws ParseException {
        //拆出路径中所有车站
        String[] sArray = path_station.split("-");//根据分隔符将各车站拆串
        List<String> stationList = new ArrayList<>(Arrays.asList(sArray));
        List<Date> timeNowList = new ArrayList<>();
        List<String> OSList = new ArrayList<>();
        List<String> DSList = new ArrayList<>();
        List<String> rateLineNameList = new ArrayList<>();

        param_code = "VER_NET_PARAM";
        gzdt_553 netVersion = gzdt_553.findDataVersion(param_code);

        if (netVersion != null) {
            String netDataVersion = netVersion.getParam_value();
            String OtransStationCode = oStationCode;
            String DtransStationCode = dStationCode;

            //判断o站/d站是否是换乘站
            if (gzdt_553.findStationName(stationList.get(0), netDataVersion, "user").size() != 0) {

                deleteRepetitiveStationResult deleteResult = deleteRepetitiveStation(stationList, netDataVersion, oStationCode, OtransStationCode, dStationCode, DtransStationCode);
                oStationCode = deleteResult.getoStationCode();
                OtransStationCode = deleteResult.getOtransStationCode();
                stationList = deleteResult.getStationList();
                dStationCode = deleteResult.getdStationCode();
                DtransStationCode = deleteResult.getDtransStationCode();

                //区间上下行方向
                String overrun_up_down = "";

                //换乘站和前一站区间上下行方向
                String overrun_beforeOs_transStationCode = "";

                //路径满载率集合
                MultiValueMap<String, Double> loadsByLine = new LinkedMultiValueMap<>();

                logger.info("odpathDetail-start");
                List<gzdt_553> OdpathDetail = gzdt_553.findDetailbyId(strid);
                logger.info("odpathDetail-end");

                if (OdpathDetail.size() != 0) {


                    //遍历路径中的各个区间
                    for (gzdt_553 stationDetail : OdpathDetail) {
//                        logger.info("one-detail-start");

                        //                }
//                    for (int z = 1, m = stationList.size(); z < m; z++) {
//                        String oS = stationList.get(z - 1);
//                        String oD = stationList.get(z);
                        String oS = stationDetail.getO_station_code_detail();
                        String oD = stationDetail.getD_station_code_detail();
                        //                        logger.info("oS:" + oS);

                        //区间上下行
                        if (gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user") != null) {
                            overrun_up_down = gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user").getUp_down();

                        }

                        String beforeOs = "";

                        Integer waitTime = 0;

                        //detail表中每个区间
//                        List<gzdt_553> stationDetail = gzdt_553.findbyODId(oS, oD, strid, "user");

//                        if (stationDetail.size() != 0) {

                        String transStationCode = stationDetail.getTrans_station_code();
                        String transLineAfcCode = stationDetail.getTrans_line_afc_code();
                        String lineAfcCode = stationDetail.getLine_afc_code();

                        if (transStationCode != null) {
                            beforeOs = OdpathDetail.get(stationDetail.getPath_station_index() - 2).getO_station_code_detail();
//                                beforeOs = stationList.get(z - 3);

                            //                            logger.info("beforeOs:" + beforeOs);
                            overrun_beforeOs_transStationCode = gzdt_553.findSectionMessageByOD(beforeOs, transStationCode, netDataVersion, "user").getUp_down();

                        }
                        //进站
                        if (stationDetail.getPath_station_index() == 1) {
//                            if (z == 1) {

                            //进站候车时间
//                                waitTime = calculateWaitTime(ifNeedBeforeDate, timeNow, waitTime, oS, oD, stationDetail, timetableVersion);
                            waitTime = findWaitTime(timeNow, oS, oD, waitTime, stationDetail, timetableVersion);

                        } else {
                            //换乘候车时间
                            if (transStationCode != null) {

//                                    waitTime = calculateWaitTime(ifNeedBeforeDate, timeNow, waitTime, oS, oD, stationDetail, timetableVersion);
                                waitTime = findWaitTime(timeNow, oS, oD, waitTime, stationDetail, timetableVersion);

                            }


                        }

                        Integer travelTime = stationDetail.getTravel_time();
                        Integer transTime = stationDetail.getTrans_time();

                        //获取满载率
                        String shike = getDataToFormatString(timeNow, "HH:mm:ss");
                        String HHmm = getDataToFormatString(timeNow, "HH:mm");
                        List<gzdt_553> load = new ArrayList<>();
                        //T-2
                        if (stationDetail.getPath_station_index() != OdpathDetail.size()) {
                            timeNowList.add(timeNow);
                            OSList.add(oS);
                            DSList.add(oD);


                            if (theDayBeforeYesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {
                                logger.info("T-2及以前，使用历史满载率");
                                //查找历史满载率
                                load = getHisLoadRate(oS, oD, departTime, HHmm, shike);
                            } else {
                                //查找特征满载率
                                load = getLoadRate(oS, oD, departTime, shike);
                            }

                        } else {
                            logger.info("最后一个区间，oS为d");
                        }


                        String lineName = gzdt_553.findLineName(netDataVersion, stationDetail.getLine_afc_code(), "user");
                        if (lineName == null) {
                            lineName = "";
                        }

                        rateLineNameList.add(lineName);
                        if (load.size() != 0) {
                            loadsByLine.add(lineName, load.get(0).getLoad_rate());

                        } else {
                            loadsByLine.add(lineName, 0.0);
                        }

                        //处理突发


                        EventInfluence eventInfluence = getEventInfluence(timeNow, transStationCode, gzdt_5531, oStationCode, dStationCode, oD, oS, OtransStationCode, DtransStationCode, beforeOs, overrun_up_down, overrun_beforeOs_transStationCode, systemDateNow, transLineAfcCode, lineAfcCode);

                        if (gzdt_5531.isSectionEventInfluence() == true) {
                            gzdt_5531.setInfluence(gzdt_5531.isSectionEventInfluence());

                        }
                        //                        gzdt_5531.setInfluence(gzdt_5531.isSectionEventInfluence());

                        //区间运行时间
                        timeNow.setTime(timeNow.getTime() + (travelTime + waitTime + transTime) * 1000);

                        totalTime = totalTime + travelTime + waitTime + transTime;
                        totalWaitTime = totalWaitTime + waitTime;
                        totalWalkTime += transTime;
                    }


//                        else {
//                            logger.info(oS + "-" + oD + "base_od_path_detail表中缺少数据");
//                        }

                    //                        logger.info("one-detail-start");
//                    }//各个区间计算延误影响
                } else {
                    logger.info(strid + "：base_od_path_detail表中缺少" + strid + "对应的数据");
                }
                gzdt_5531.setTotal_time(totalTime);// 更新总旅行时间
                gzdt_5531.setWait_time(totalWaitTime);// 计算等待时间
                gzdt_5531.setTotalWalkTime(totalWalkTime);// 计算走行时间

                //获得路径中各线路最大满载率
                findMaxLoadByLine(loadsByLine, gzdt_5531);


                //处理pathName和线路颜色
                String[] pathName = gzdt_5531.getPath_name().split("\\(|-|\\)");
                List<String> pathNameList = new ArrayList<>();
                List<String> lineNameList = new ArrayList<>();

                Map<String, String> linesColor = new LinkedHashMap();
                Map<String, String> enLinesColor = new LinkedHashMap();

                StringBuilder stringBuilder = new StringBuilder();

                for (String pathNa : pathName) {

                    if (pathNa.length() != 0) {
                        pathNameList.add(pathNa);
                    }
                }

                for (int i = 0; i < pathNameList.size(); i++) {
                    if (i % 2 == 0) {
                        String pathStationName = gzdt_553.findStationName(pathNameList.get(i), netDataVersion, "user").get(0).getStation_name();

                        stringBuilder.append(pathStationName);
                    } else {
                        String pathLineName = gzdt_553.findLineName(netDataVersion, pathNameList.get(i), "user");

                        lineNameList.add(pathLineName);
                        stringBuilder.append("(" + pathLineName + ")-");
                    }
                }

                for (int i = 0; i < lineNameList.size(); i++) {
                    String lineName = lineNameList.get(i);
                    String lineColor = paramLineService.findLineColor(netDataVersion, lineName);
                    String enLineName = gzdt_553.findLineEnName(netDataVersion, lineName, "user");

                    linesColor.put(lineName, lineColor);
                    enLinesColor.put(enLineName, lineColor);
                }

//                //获取满载率
//                //T-2
//                if (theDayBeforeYesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {
//                    logger.info("查找历史满载率");
//                    //查找历史满载率
//                    for (int i = 0; i < timeNowList.size(); i++) {
//
//                        List<gzdt_553> load = new ArrayList<>();
////                            logger.info("T-2及以前，使用历史满载率");
//
//                        String shike = getDataToFormatString(timeNowList.get(i), "HH:mm:ss");
//                        String HHmm = getDataToFormatString(timeNowList.get(i), "HH:mm");
//                        load = getHisLoadRate(OSList.get(i), DSList.get(i), departTime, HHmm, shike);
//
//                        if (load.size() != 0) {
//                            loadsByLine.add(rateLineNameList.get(i), load.get(0).getLoad_rate());
//
//                        } else {
//                            loadsByLine.add(rateLineNameList.get(i), 0.0);
//                        }
//                    }
//                } else {
//                    logger.info("查找特征满载率");
//                    for (int i = 0; i < timeNowList.size(); i++) {
//                        //查找特征满载率
//                        List<gzdt_553> load = new ArrayList<>();
//                        String shike = getDataToFormatString(timeNowList.get(i), "HH:mm:ss");
//                        load = getLoadRate(OSList.get(i), DSList.get(i), departTime, shike);
//
//                        if (load.size() != 0) {
//                            loadsByLine.add(rateLineNameList.get(i), load.get(0).getLoad_rate());
//
//                        } else {
//                            loadsByLine.add(rateLineNameList.get(i), 0.0);
//                        }
//                    }
//
//                }

                //获得路径中各线路最大满载率
                findMaxLoadByLine(loadsByLine, gzdt_5531);

                gzdt_5531.setLinesColor(linesColor);
                gzdt_5531.setEnLinesColor(enLinesColor);
                gzdt_5531.setChinesePathName(stringBuilder.toString());
            }
        } else {
            logger.info("param_station缺少当前net的版本号对应的数据");
        }

        finalPaths.add(gzdt_5531);

    }

//    public void calculatePath(String path_station, String param_code, String oStationCode, String dStationCode, String strid, boolean ifNeedBeforeDate, Date timeNow, Date theDayBeforeYesterdayDateNow, Date departTime, gzdt_553 gzdt_5531, Integer totalTime, Integer totalWaitTime, Integer totalWalkTime, List<gzdt_553> finalPaths, Date systemDateNow, String timetableVersion) throws ParseException {
//        //拆出路径中所有车站
//        String[] sArray = path_station.split("-");//根据分隔符将各车站拆串
//        List<String> stationList = new ArrayList<>(Arrays.asList(sArray));
//
//        param_code = "VER_NET_PARAM";
//        gzdt_553 netVersion = gzdt_553.findDataVersion(param_code);
//
//        if (netVersion != null) {
//            String netDataVersion = netVersion.getParam_value();
//            String OtransStationCode = oStationCode;
//            String DtransStationCode = dStationCode;
//
//            //判断o站/d站是否是换乘站
//            if (gzdt_553.findStationName(stationList.get(0), netDataVersion, "user").size() != 0) {
//
//                deleteRepetitiveStationResult deleteResult = deleteRepetitiveStation(stationList, netDataVersion, oStationCode, OtransStationCode, dStationCode, DtransStationCode);
//                oStationCode = deleteResult.getoStationCode();
//                OtransStationCode = deleteResult.getOtransStationCode();
//                stationList = deleteResult.getStationList();
//                dStationCode = deleteResult.getdStationCode();
//                DtransStationCode = deleteResult.getDtransStationCode();
//
//                //区间上下行方向
//                String overrun_up_down = "";
//
//                //换乘站和前一站区间上下行方向
//                String overrun_beforeOs_transStationCode = "";
//
//                //路径满载率集合
//                MultiValueMap<String, Double> loadsByLine = new LinkedMultiValueMap<>();
//
//                //遍历路径中的各个区间
//                for (int z = 1, m = stationList.size(); z < m; z++) {
//                    String oS = stationList.get(z - 1);
//                    String oD = stationList.get(z);
//
//                    //区间上下行
//                    if (gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user") != null) {
//                        overrun_up_down = gzdt_553.findSectionMessageByOD(oS, oD, netDataVersion, "user").getUp_down();
//
//                    }
//
//                    String beforeOs = "";
//
//                    Integer waitTime = 0;
//
//                    //detail表中每个区间
//                    List<gzdt_553> stationDetail = gzdt_553.findbyODId(oS, oD, strid, "user");
//
//                    if (stationDetail.size() != 0) {
//
//                        String transStationCode = stationDetail.get(0).getTrans_station_code();
//                        String transLineAfcCode = stationDetail.get(0).getTrans_line_afc_code();
//                        String lineAfcCode = stationDetail.get(0).getLine_afc_code();
//
//                        if (transStationCode != null) {
//                            beforeOs = stationList.get(z - 3);
//
//                            overrun_beforeOs_transStationCode = gzdt_553.findSectionMessageByOD(beforeOs, transStationCode, netDataVersion, "user").getUp_down();
//
//                        }
//                        //进站
//                        if (z == 1) {
//
//                            //进站候车时间
////                            waitTime = calculateWaitTime(ifNeedBeforeDate, timeNow, waitTime, oS, oD, stationDetail, timetableVersion);
//                            waitTime = findWaitTime(timeNow, oS, oD, waitTime, stationDetail, timetableVersion);
//
//                        } else {
//                            //换乘候车时间
//                            if (transStationCode != null) {
//
//                                waitTime = findWaitTime(timeNow, oS, oD, waitTime, stationDetail, timetableVersion);
////                                waitTime = calculateWaitTime(ifNeedBeforeDate, timeNow, waitTime, oS, oD, stationDetail, timetableVersion);
//
//                            }
//
//
//                        }
//
//                        Integer travelTime = stationDetail.get(0).getTravel_time();
//                        Integer transTime = stationDetail.get(0).getTrans_time();
//
//                        //获取满载率
//                        String shike = getDataToFormatString(timeNow, "HH:mm:ss");
//                        String HHmm = getDataToFormatString(timeNow, "HH:mm");
//                        List<gzdt_553> load = new ArrayList<>();
//                        //T-2
//                        if (theDayBeforeYesterdayDateNow.getTime() >= getForDate(departTime).getTime()) {
//
//                            logger.info("T-2及以前，使用历史满载率");
//                            //查找历史满载率
//                            load = getHisLoadRate(oS, oD, departTime, HHmm, shike);
//                        } else {
//                            //查找特征满载率
//                            load = getLoadRate(oS, oD, departTime, shike);
//                        }
//
//                        String lineName = gzdt_553.findLineName(netDataVersion, stationDetail.get(0).getLine_afc_code(), "user");
//                        if (lineName == null) {
//                            lineName = "";
//                        }
//                        if (load.size() != 0) {
//                            loadsByLine.add(lineName, load.get(0).getLoad_rate());
//
//                        } else {
//                            loadsByLine.add(lineName, 0.0);
//                        }
//
//                        //处理突发
//
//
//                        EventInfluence eventInfluence = getEventInfluence(timeNow, transStationCode, gzdt_5531, oStationCode, dStationCode, oD, oS, OtransStationCode, DtransStationCode, beforeOs, overrun_up_down, overrun_beforeOs_transStationCode, systemDateNow, transLineAfcCode, lineAfcCode);
//
//                        if (gzdt_5531.isSectionEventInfluence() == true) {
//                            gzdt_5531.setInfluence(gzdt_5531.isSectionEventInfluence());
//
//                        }
//                        //                        gzdt_5531.setInfluence(gzdt_5531.isSectionEventInfluence());
//
//                        //区间运行时间
//                        timeNow.setTime(timeNow.getTime() + (travelTime + waitTime + transTime) * 1000);
//
//                        totalTime = totalTime + travelTime + waitTime + transTime;
//                        totalWaitTime = totalWaitTime + waitTime;
//                        totalWalkTime += transTime;
//                    } else {
//                        logger.info(oS + "-" + oD + "base_od_path_detail表中缺少数据");
//                    }
//
//                }//各个区间计算延误影响
//                gzdt_5531.setTotal_time(totalTime);// 更新总旅行时间
//                gzdt_5531.setWait_time(totalWaitTime);// 计算等待时间
//                gzdt_5531.setTotalWalkTime(totalWalkTime);// 计算走行时间
//
//                //获得路径中各线路最大满载率
//                findMaxLoadByLine(loadsByLine, gzdt_5531);
//
//
//                //处理pathName和线路颜色
//                String[] pathName = gzdt_5531.getPath_name().split("\\(|-|\\)");
//                List<String> pathNameList = new ArrayList<>();
//                List<String> lineNameList = new ArrayList<>();
//
//                Map<String, String> linesColor = new LinkedHashMap();
//                Map<String, String> enLinesColor = new LinkedHashMap();
//
//                StringBuilder stringBuilder = new StringBuilder();
//
//                for (String pathNa : pathName) {
//
//                    if (pathNa.length() != 0) {
//                        pathNameList.add(pathNa);
//                    }
//                }
//
//                for (int i = 0; i < pathNameList.size(); i++) {
//                    if (i % 2 == 0) {
//                        String pathStationName = gzdt_553.findStationName(pathNameList.get(i), netDataVersion, "user").get(0).getStation_name();
//
//                        stringBuilder.append(pathStationName);
//                    } else {
//                        String pathLineName = gzdt_553.findLineName(netDataVersion, pathNameList.get(i), "user");
//
//                        lineNameList.add(pathLineName);
//                        stringBuilder.append("(" + pathLineName + ")-");
//                    }
//                }
//
//                for (int i = 0; i < lineNameList.size(); i++) {
//                    String lineName = lineNameList.get(i);
//                    String lineColor = paramLineService.findLineColor(netDataVersion, lineName);
//                    String enLineName = gzdt_553.findLineEnName(netDataVersion, lineName, "user");
//
//                    linesColor.put(lineName, lineColor);
//                    enLinesColor.put(enLineName, lineColor);
//                }
//
//
//                gzdt_5531.setLinesColor(linesColor);
//                gzdt_5531.setEnLinesColor(enLinesColor);
//                gzdt_5531.setChinesePathName(stringBuilder.toString());
//
//            } else {
//                logger.info("param_station缺少当前net的版本号对应的数据");
//            }
//
//        } else {
//
//            logger.info("param_runtime缺少当前net的版本号");
//        }
//
//        finalPaths.add(gzdt_5531);
//        //        return gzdt_5531;
//    }

    public OdPathResponseData calculatePasLevelValue(BasePassFavLevel basePassFavLevel, gzdt_553 route, OdPathResponseData data) {

        //        logger.info("basePassFavLevel.getFirst_fav():"+basePassFavLevel.getFirst_fav());

        if (basePassFavLevel.getFirst_fav().equals("times")) {
            //            logger.info("route.getTotal_time():"+route.getTotal_time());
            data.setFirstValue(route.getTotal_time().doubleValue());
        } else if (basePassFavLevel.getFirst_fav().equals("trans")) {
            data.setFirstValue(route.getTrans_amount().doubleValue());
        } else if (basePassFavLevel.getFirst_fav().equals("load")) {
            //            logger.info("route.getTotal_time():"+route.getTotal_time());
            data.setFirstValue(route.getLoad_rate().doubleValue());
        }

        if (basePassFavLevel.getSecond_fav().equals("times")) {
            data.setSecondValue(route.getTotal_time().doubleValue());
        } else if (basePassFavLevel.getSecond_fav().equals("trans")) {
            data.setSecondValue(route.getTrans_amount().doubleValue());
        } else if (basePassFavLevel.getSecond_fav().equals("load")) {

            data.setSecondValue(route.getLoad_rate().doubleValue());
        }

        if (basePassFavLevel.getThird_fav().equals("times")) {
            data.setThirdValue(route.getTotal_time().doubleValue());
        } else if (basePassFavLevel.getThird_fav().equals("trans")) {
            data.setThirdValue(route.getTrans_amount().doubleValue());
        } else if (basePassFavLevel.getThird_fav().equals("load")) {
            data.setThirdValue(route.getLoad_rate().doubleValue());
        }

        //        logger.info("data.getThirdValue():"+data.getThirdValue());
        return data;
    }

    public List<JSONObject> OdPathResponseDataToJSONObject(OdPathResponseData data, List<JSONObject> jsonArray) {
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("oStationCode", data.getoStationCode());
        jsonObject.put("dStationCode", data.getdStationCode());
        jsonObject.put("pathIndex", data.getPathIndex());
        jsonObject.put("pathName", data.getPathName());
        jsonObject.put("stationAmount", data.getStationAmount());
        jsonObject.put("transAmount", data.getTransAmount());
        jsonObject.put("ticketPrice", data.getTicketPrice());
        jsonObject.put("totalTime", data.getTotalTime());
        jsonObject.put("load_rate", data.getLoad_rate());
        jsonObject.put("load_rate_color", data.getLoad_rate_color());
        jsonObject.put("linesLoadRate", data.getLinesLoadRate());
        jsonObject.put("linesLoadLevel", data.getLinesLoadLevel());
        jsonObject.put("recoType", data.getRecoType());
        jsonObject.put("departTime", data.getDepartTime());
        jsonObject.put("logitValue", data.getLogitValue());
        jsonObject.put("recordId", data.getRecordId());
        jsonObject.put("linesColor", data.getLinesColor());
        jsonObject.put("enLinesColor", data.getEnLinesColor());

        jsonObject.put("pathLastTime", data.getPathLastTime());
        jsonObject.put("enPathLastTime", data.getEnPathLastTime());

        jsonArray.add(jsonObject);
        return jsonArray;
    }

}

