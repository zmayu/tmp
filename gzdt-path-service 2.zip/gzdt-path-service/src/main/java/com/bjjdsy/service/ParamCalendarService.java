package com.bjjdsy.service;

import com.bjjdsy.mapper.ParamCalendarMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class ParamCalendarService {
    @Resource
    private ParamCalendarMapper paramCalendarMapper;

//    public List<Date> findCalendarDayList(String day_type,String week_day){return paramCalendarMapper.findCalendarDayList(day_type,week_day);}

    public List<Date> findCalendarDayList(Integer day_type, Integer week_day, Date systemDateNow) {
        return paramCalendarMapper.findCalendarDayList(day_type, week_day, systemDateNow);
    }

}
