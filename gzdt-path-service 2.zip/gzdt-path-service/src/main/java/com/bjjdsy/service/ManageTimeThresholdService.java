package com.bjjdsy.service;

import com.bjjdsy.mapper.ManageTimeThresholdMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class ManageTimeThresholdService {
    @Resource
    ManageTimeThresholdMapper manageTimeThresholdMapper;

    public Integer findTimeThresholdByType() {return manageTimeThresholdMapper.findTimeThresholdByType();}
}
