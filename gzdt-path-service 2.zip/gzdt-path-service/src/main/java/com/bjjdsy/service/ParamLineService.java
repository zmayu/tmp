package com.bjjdsy.service;

import com.bjjdsy.mapper.ParamLineMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class ParamLineService {
    @Resource
    private ParamLineMapper paramLineMapper;

    public String findLineColor(String versionCode, String lineName){return paramLineMapper.findLineColor(versionCode,lineName);}

}
