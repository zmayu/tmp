package com.bjjdsy.service;

import com.bjjdsy.mapper.BasePassFavLevelMapper;
import com.bjjdsy.pojo.BasePassFavLevel;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class BasePassFavLevelService {

    @Resource
    private BasePassFavLevelMapper basePassFavLevelMapper;

    public BasePassFavLevel findPassFavLevel(String userId) {
        return basePassFavLevelMapper.findPassFavLevel(userId);
    }

}
