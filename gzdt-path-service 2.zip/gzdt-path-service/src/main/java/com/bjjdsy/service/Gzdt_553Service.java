package com.bjjdsy.service;

import com.bjjdsy.mapper.gzdt_553Mapper;
import com.bjjdsy.pojo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

//import com.bjjdsy.pojo.RecommendPath;

@Service
public class Gzdt_553Service {
    private static final Logger logger = LoggerFactory.getLogger(Gzdt_553Service.class);

    @Resource
    private gzdt_553Mapper gzdt_553;

    //    public List<gzdt_553> findbyOD(String oStationCode, String dStationCode,String dataVersion){return  gzdt_553.findbyOD(oStationCode, dStationCode,dataVersion);}
    public List<gzdt_553> findbyOD(String oStationCode, String dStationCode, String dataVersion, String user) {
        return gzdt_553.findbyOD(oStationCode, dStationCode, dataVersion, user);
    }

    //    public List<gzdt_553> findbyODIndex(String oStationCode, String dStationCode, Integer pathIndex,String dataVersion){return  gzdt_553.findbyODIndex(oStationCode, dStationCode, pathIndex,dataVersion);}
    public List<gzdt_553> findbyODIndex(String oStationCode, String dStationCode, Integer pathIndex, String dataVersion, String user) {
        return gzdt_553.findbyODIndex(oStationCode, dStationCode, pathIndex, dataVersion, user);
    }

    //    public List<gzdt_553> findbyODId(String oStationCodedetail, String dStationCodedetail, String id){return  gzdt_553.findbyODId(oStationCodedetail, dStationCodedetail, id);}
    public List<gzdt_553> findbyODId(String oStationCodedetail, String dStationCodedetail, String id, String user) {
        return gzdt_553.findbyODId(oStationCodedetail, dStationCodedetail, id, user);
    }

    public List<gzdt_553> findDetailbyId(String id) {
        return gzdt_553.findDetailbyId(id);
    }
    //    public List<gzdt_553> findFinalTime(String oStationCode, String dStationCode,String data_version){return  gzdt_553.findFinalTime(oStationCode, dStationCode,data_version);}

    public List<BaseOdPathLast> findFinalTime(String oStationCode, String dStationCode, String data_version, String pathStations, String user) {return gzdt_553.findFinalTime(oStationCode, dStationCode, data_version, pathStations,user);}

    public List<BaseOdPathLast> findOdFinalTime(String dataVersion, String oStationCode, String dStationCode) {return gzdt_553.findOdFinalTime(dataVersion, oStationCode, dStationCode);}


    public List<BaseOdPathLast> findOdPathFinalTime(String dataVersion, String pathStations) {
        return gzdt_553.findOdPathFinalTime(dataVersion, pathStations);
    }

    //    public List<gzdt_553> findStationName(String stationCode,String dataVersion){return  gzdt_553.findStationName(stationCode,dataVersion);}
    public List<gzdt_553> findStationName(String stationCode, String dataVersion, String user) {
        return gzdt_553.findStationName(stationCode, dataVersion, user);
    }

    //    public List<gzdt_553> findDelayByDate(Date departTime){return  gzdt_553.findDelayByDate(departTime);}
//    public List<gzdt_553> findDelayByDate(Date departTime, String user) {
//        return gzdt_553.findDelayByDate(departTime, user);
//    }

//    public List<EventInfluenceData> findDelayByDate(Date departTime, String user) {
//        return gzdt_553.findDelayByDate(departTime, user);
//    }

    public List<EventInfluenceData> findDelayByDate(Date departTime, String user, Date systemDateNow) {
        return gzdt_553.findDelayByDate(departTime, user, systemDateNow);
    }

    public List<gzdt_553> findFavById(String userId) {
        return gzdt_553.findFavById(userId);
    }

    //    public  List<gzdt_553> findNormalLimitByOTime(String oStationCode, String departTime,String dataVersion){return gzdt_553.findNormalLimitByOTime(oStationCode, departTime,dataVersion);}
    public List<gzdt_553> findNormalLimitByOTime(String oStationCode, String departTime, String dataVersion, String user) {
        return gzdt_553.findNormalLimitByOTime(oStationCode, departTime, dataVersion, user);
    }

    //    public  List<gzdt_553> findChaRateByDayTypeWeekDay(String oStationCode,String dStationCode, Integer day_type,Integer week_day, String shike,String dataVersion){return gzdt_553.findChaRateByDayTypeWeekDay(oStationCode, dStationCode, day_type, week_day, shike,dataVersion);}
    public List<gzdt_553> findChaRateByDayTypeWeekDay(String oStationCode, String dStationCode, Integer day_type, Integer week_day, String shike, String dataVersion, String user) {
        return gzdt_553.findChaRateByDayTypeWeekDay(oStationCode, dStationCode, day_type, week_day, shike, dataVersion, user);
    }

    public List<gzdt_553> findHisRateByDate(String oStationCode, String dStationCode, String shike, String calendar_day, String user) {
        return gzdt_553.findHisRateByDate(oStationCode, dStationCode, shike, calendar_day, user);
    }

    //    public gzdt_553 findDataTypeWeekDay(Date calendar_day){return gzdt_553.findDataTypeWeekDay(calendar_day);}
    public gzdt_553 findDataTypeWeekDay(Date calendar_day, String user) {
        return gzdt_553.findDataTypeWeekDay(calendar_day, user);
    }

    public String findDataType(Date calendar_day, String user) {
        return gzdt_553.findDataType(calendar_day, user);
    }

    //    public gzdt_553 findOdLastVersion(Date calendar_day){return gzdt_553.findOdLastVersion(calendar_day);}
    public gzdt_553 findOdLastVersion(Date calendar_day, String user) {
        return gzdt_553.findOdLastVersion(calendar_day, user);
    }

    public gzdt_553 findDataVersion(String param_code) {
        return gzdt_553.findDataVersion(param_code);
    }

    //    public gzdt_553 findSectionDStationCode(String oStationCode, String up_down,String version_code){return gzdt_553.findSectionDStationCode(oStationCode,up_down,version_code);}
    public gzdt_553 findSectionDStationCode(String oStationCode, String up_down, String version_code, String user) {
        return gzdt_553.findSectionDStationCode(oStationCode, up_down, version_code, user);
    }

    public ParamSection findSectionMessageByOD(String oStationCode, String dStationCode, String version_code, String user) {
        return gzdt_553.findSectionMessageByOD(oStationCode, dStationCode, version_code, user);
    }

    public ParamSection findSectionMessageByODirection(String oStationCode, String up_down, String version_code) {
        return gzdt_553.findSectionMessageByODirection(oStationCode, up_down, version_code);
    }

    public ParamSection findSectionMessageByODirectionLineAfc(String oStationCode, String up_down, String version_code, String line_afc_code) {
        return gzdt_553.findSectionMessageByODirectionLineAfc(oStationCode, up_down, version_code, line_afc_code);
    }

    //    public String findAverageWaitTime(String oStationCode, String dStationCode, String hour,String dataVersion){return gzdt_553.findAverageWaitTime(oStationCode,dStationCode,hour,dataVersion);}
    public String findAverageWaitTime(String oStationCode, String dStationCode, String hour, String dataVersion, String user) {
        return gzdt_553.findAverageWaitTime(oStationCode, dStationCode, hour, dataVersion, user);
    }

//    public List<String> findODAverageWaitTime(String oStationCode, String dStationCode, String dataVersion){
//        return gzdt_553.findODAverageWaitTime(oStationCode, dStationCode, dataVersion);
//    }

    public List<String> findODAverageWaitTime(String dataVersion) {
        return gzdt_553.findODAverageWaitTime(dataVersion);
    }

    //    public String findTimeTableVersion(Date calendar_day){return gzdt_553.findTimeTableVersion(calendar_day);}
    public String findTimeTableVersion(Date calendar_day, String user) {
        return gzdt_553.findTimeTableVersion(calendar_day, user);
    }

    //    public PassFavCoefficient findFavCoefficient(String userId){return gzdt_553.findFavCoefficient(userId);}
    public PassFavCoefficient findFavCoefficient(String userId, String user) {
        return gzdt_553.findFavCoefficient(userId);
    }

    //    public String findLineName(String versionCode,String lineAfcCode){return gzdt_553.findLineName(versionCode,lineAfcCode);}
    public String findLineName(String versionCode, String lineAfcCode, String user) {
        return gzdt_553.findLineName(versionCode, lineAfcCode, user);
    }

    //    public String findLineEnName(String versionCode,String lineName){return gzdt_553.findLineEnName(versionCode, lineName);}
    public String findLineEnName(String versionCode, String lineName, String user) {
        return gzdt_553.findLineEnName(versionCode, lineName, user);
    }

    public String findStationEnName(String versionCode, String stationCode, String lineAfcCode) {
        return gzdt_553.findStationEnName(versionCode, stationCode, lineAfcCode);
    }

    public List<String> findStationCode(String versionCode, String stationName, String user) {
        return gzdt_553.findStationCode(versionCode, stationName,user);
    }

    public List<ParamLoadRate> findParamLoadRate() {
        return gzdt_553.findParamLoadRate();
    }

}
