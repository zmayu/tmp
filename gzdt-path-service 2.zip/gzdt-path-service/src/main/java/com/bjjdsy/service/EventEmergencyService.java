package com.bjjdsy.service;

import com.bjjdsy.mapper.EventEmergencyMapper;
import com.bjjdsy.pojo.EventEmergency;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class EventEmergencyService {
    @Resource
    private EventEmergencyMapper eventEmergencyMapper;

    public EventEmergency findByRecordId(Integer record_id) {return eventEmergencyMapper.findByRecordId(record_id);}

}
