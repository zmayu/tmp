package com.bjjdsy.pojo;

public class MinTypeValues {
    private Integer timeleast;
    private Integer transferLeast;
    private Integer waitLeast;
    private double overallbest;
    private double loadmin;

    public Integer getTimeleast() {
        return timeleast;
    }

    public void setTimeleast(Integer timeleast) {
        this.timeleast = timeleast;
    }

    public Integer getTransferLeast() {
        return transferLeast;
    }

    public void setTransferLeast(Integer transferLeast) {
        this.transferLeast = transferLeast;
    }

    public Integer getWaitLeast() {
        return waitLeast;
    }

    public void setWaitLeast(Integer waitLeast) {
        this.waitLeast = waitLeast;
    }

    public double getOverallbest() {
        return overallbest;
    }

    public void setOverallbest(double overallbest) {
        this.overallbest = overallbest;
    }

    public double getLoadmin() {
        return loadmin;
    }

    public void setLoadmin(double loadmin) {
        this.loadmin = loadmin;
    }
}
