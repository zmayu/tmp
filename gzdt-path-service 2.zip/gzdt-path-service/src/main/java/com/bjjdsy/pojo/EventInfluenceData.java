package com.bjjdsy.pojo;

import java.util.Date;

public class EventInfluenceData {

    private String event_type;
    private Integer event_record_id;
    private Integer limit_type;
    private String o_line_afc_code;
    private String o_station_code;
    private String d_line_afc_code;
    private String d_station_code;
    private String up_down;
    private Integer limit_time;
    private Date start_time;
    private Date end_time;


    public String getEvent_type() {
        return event_type;
    }

    public void setEvent_type(String event_type) {
        this.event_type = event_type;
    }

    public Integer getEvent_record_id() {
        return event_record_id;
    }

    public void setEvent_record_id(Integer event_record_id) {
        this.event_record_id = event_record_id;
    }

//    public String getLimit_type() {
//        return limit_type;
//    }
//
//    public void setLimit_type(String limit_type) {
//        this.limit_type = limit_type;
//    }

    public String getO_line_afc_code() {
        return o_line_afc_code;
    }

    public void setO_line_afc_code(String o_line_afc_code) {
        this.o_line_afc_code = o_line_afc_code;
    }

    public String getO_station_code() {
        return o_station_code;
    }

    public void setO_station_code(String o_station_code) {
        this.o_station_code = o_station_code;
    }

    public String getD_line_afc_code() {
        return d_line_afc_code;
    }

    public void setD_line_afc_code(String d_line_afc_code) {
        this.d_line_afc_code = d_line_afc_code;
    }

    public String getD_station_code() {
        return d_station_code;
    }

    public void setD_station_code(String d_station_code) {
        this.d_station_code = d_station_code;
    }

    public String getUp_down() {
        return up_down;
    }

    public void setUp_down(String up_down) {
        this.up_down = up_down;
    }

    public Integer getLimit_time() {
        return limit_time;
    }

    public void setLimit_time(Integer limit_time) {
        this.limit_time = limit_time;
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public Integer getLimit_type() {
        return limit_type;
    }

    public void setLimit_type(Integer limit_type) {
        this.limit_type = limit_type;
    }
}
