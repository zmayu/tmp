package com.bjjdsy.pojo;

import java.util.Date;

public class NormalStationLimit {
    private Date timeNow;
//    private Integer totalTime;
    private Integer waitTime;
    private Integer minDelayTime;
    private Integer maxDelayTime;

    public Date getTimeNow() {
        return timeNow;
    }

    public void setTimeNow(Date timeNow) {
        this.timeNow = timeNow;
    }

//    public Integer getTotalTime() {
//        return totalTime;
//    }
//
//    public void setTotalTime(Integer totalTime) {
//        this.totalTime = totalTime;
//    }

    public Integer getWaitTime() {
        return waitTime;
    }

    public void setWaitTime(Integer waitTime) {
        this.waitTime = waitTime;
    }

    public Integer getMinDelayTime() {
        return minDelayTime;
    }

    public void setMinDelayTime(Integer minDelayTime) {
        this.minDelayTime = minDelayTime;
    }

    public Integer getMaxDelayTime() {
        return maxDelayTime;
    }

    public void setMaxDelayTime(Integer maxDelayTime) {
        this.maxDelayTime = maxDelayTime;
    }
}
