package com.bjjdsy.pojo;

public class BasePassFavLevel {

    private String user_id;
    private String first_fav;
    private String second_fav;
    private String third_fav;


    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getFirst_fav() {
        return first_fav;
    }

    public void setFirst_fav(String first_fav) {
        this.first_fav = first_fav;
    }

    public String getSecond_fav() {
        return second_fav;
    }

    public void setSecond_fav(String second_fav) {
        this.second_fav = second_fav;
    }

    public String getThird_fav() {
        return third_fav;
    }

    public void setThird_fav(String third_fav) {
        this.third_fav = third_fav;
    }
}
