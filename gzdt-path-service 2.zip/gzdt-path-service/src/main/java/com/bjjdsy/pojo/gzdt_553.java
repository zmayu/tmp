package com.bjjdsy.pojo;

import java.util.Date;
import java.util.Map;

public class gzdt_553 {

    private Long id;
    private String lineName;
    private Integer stationNum;
    private String length;

    private String line_afc_code;
    private String direct_station_code;

    private Integer record_id;
    private String data_version;
    private String o_station_code;
    private String d_station_code;
    private Integer path_index;
    private String path_stations;
    private String path_name;
    private Integer station_amount;
    private Integer trans_amount;
    private Integer path_distance;
    private Integer ticket_price;
    private Integer total_time;
    private double v_logit;

    private Integer path_info_id;
    private String trans_line_name;
    //    private String trans_line_afc_code;
    private String trans_station_code;
    private String line_name;
    private String o_station_code_detail;
    private String d_station_code_detail;
    private Integer trans_time;
    private Integer wait_time;
    private Integer travel_time;
    private Integer path_station_index;
    private Integer path_station_type;
    private String o_station_name;
    private String direct_station_name;

    private String begin_time;
    private String last_time;

    private String station_code;
    private String station_name;
    private String version_code;

    private String event_type;
    private Integer event_record_id;
    private Integer limit_time;
    private Date start_time;
    private Date end_time;

    private Double time_value;
    private Double trans_value;
    private Double comfort_value;
    private Double wait_value;
    private String user_id;

    private Integer limit_type;
    private String week_days;

    private Date calendar_day;
    private Double load_rate;
    private String load_rate_color;

    private Integer day_type;
    private Integer week_day;

    private String start_timeshike;
    private String end_timeshike;

    private boolean Influence;//不跟随区间刷新
    private boolean eventPassengerFlowControl;//突发客控
    private boolean overrun;//越行
    private boolean delaysOrInterruptions;//延误或者中断
    private boolean sectionEventInfluence;//跟随区间刷新
    private String overrunDirectionStation;//越行方向站


    private Map<String, Double> linesLoadRate;
    private Map<String, Integer> linesLoadLevel;

    private String update_user;
    private String update_time;

    private String param_code;
    private String param_name;
    private String param_value;

    private String station_limit_level;
    private String event_comment;
    private String control_type;
    private Integer min_delay_time;
    private Integer max_delay_time;

    private Integer totalWalkTime;
    private String trans_line_afc_code;
    private String chinesePathName;

    private String recoType;

    private Integer passFavLevel;

    private Integer up_down;

    private Map<String, String> linesColor;
    private Map<String, String> enLinesColor;

//    private Integer path_station_index;

//    private double minload;

    private String pathLastTime;
    private String enPathLastTime;

    public Integer getWeek_day() {
        return week_day;
    }

    public void setWeek_day(Integer week_day) {
        this.week_day = week_day;
    }

    public String getStart_timeshike() {
        return start_timeshike;
    }

    public void setStart_timeshike(String start_timeshike) {
        this.start_timeshike = start_timeshike;
    }

    public String getEnd_timeshike() {
        return end_timeshike;
    }

    public void setEnd_timeshike(String end_timeshike) {
        this.end_timeshike = end_timeshike;
    }

    public Integer getDay_type() {
        return day_type;
    }

    public void setDay_type(Integer day_type) {
        this.day_type = day_type;
    }

    public Date getCalendar_day() {
        return calendar_day;
    }

    public void setCalendar_day(Date calendar_day) {
        this.calendar_day = calendar_day;
    }

    public Double getLoad_rate() {
        return load_rate;
    }

    public void setLoad_rate(Double load_rate) {
        this.load_rate = load_rate;
    }

    public Integer getLimit_type() {
        return limit_type;
    }

    public void setLimit_type(Integer limit_type) {
        this.limit_type = limit_type;
    }

    public String getWeek_days() {
        return week_days;
    }

    public void setWeek_days(String week_days) {
        this.week_days = week_days;
    }

    public double getV_logit() {
        return v_logit;
    }

    public void setV_logit(double v_logit) {
        this.v_logit = v_logit;
    }

    public Double getTime_value() {
        return time_value;
    }

    public void setTime_value(Double time_value) {
        this.time_value = time_value;
    }

    public Double getTrans_value() {
        return trans_value;
    }

    public void setTrans_value(Double trans_value) {
        this.trans_value = trans_value;
    }

    public Double getComfort_value() {
        return comfort_value;
    }

    public void setComfort_value(Double comfort_value) {
        this.comfort_value = comfort_value;
    }

    public Double getWait_value() {
        return wait_value;
    }

    public void setWait_value(Double wait_value) {
        this.wait_value = wait_value;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getEvent_type() {
        return event_type;
    }

    public void setEvent_type(String event_type) {
        this.event_type = event_type;
    }

    public Integer getEvent_record_id() {
        return event_record_id;
    }

    public void setEvent_record_id(Integer event_record_id) {
        this.event_record_id = event_record_id;
    }

    public Integer getLimit_time() {
        return limit_time;
    }

    public void setLimit_time(Integer limit_time) {
        this.limit_time = limit_time;
    }

    public Date getStart_time() {
        return start_time;
    }

    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public String getVersion_code() {
        return version_code;
    }

    public void setVersion_code(String version_code) {
        this.version_code = version_code;
    }

    public String getStation_code() {
        return station_code;
    }

    public void setStation_code(String station_code) {
        this.station_code = station_code;
    }

    public String getStation_name() {
        return station_name;
    }

    public void setStation_name(String station_name) {
        this.station_name = station_name;
    }

    public String getBegin_time() {
        return begin_time;
    }

    public void setBegin_time(String begin_time) {
        this.begin_time = begin_time;
    }

    public String getLast_time() {
        return last_time;
    }

    public void setLast_time(String last_time) {
        this.last_time = last_time;
    }

    public Integer getPath_info_id() {
        return path_info_id;
    }

    public void setPath_info_id(Integer path_info_id) {
        this.path_info_id = path_info_id;
    }

    public String getTrans_line_name() {
        return trans_line_name;
    }

    public void setTrans_line_name(String trans_line_name) {
        this.trans_line_name = trans_line_name;
    }

    public String getTrans_station_code() {
        return trans_station_code;
    }

    public void setTrans_station_code(String trans_station_code) {
        this.trans_station_code = trans_station_code;
    }

    public String getLine_name() {
        return line_name;
    }

    public void setLine_name(String line_name) {
        this.line_name = line_name;
    }

    public String getDirect_station_name() {
        return direct_station_name;
    }

    public void setDirect_station_name(String direct_station_name) {
        this.direct_station_name = direct_station_name;
    }

    public String getO_station_code_detail() {
        return o_station_code_detail;
    }

    public void setO_station_code_detail(String o_station_code_detail) {
        this.o_station_code_detail = o_station_code_detail;
    }

    public String getD_station_code_detail() {
        return d_station_code_detail;
    }

    public void setD_station_code_detail(String d_station_code_detail) {
        this.d_station_code_detail = d_station_code_detail;
    }

    public Integer getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Integer trans_time) {
        this.trans_time = trans_time;
    }

    public Integer getWait_time() {
        return wait_time;
    }

    public void setWait_time(Integer wait_time) {
        this.wait_time = wait_time;
    }

    public Integer getTravel_time() {
        return travel_time;
    }

    public void setTravel_time(Integer travel_time) {
        this.travel_time = travel_time;
    }

    public Integer getPath_station_index() {
        return path_station_index;
    }

    public void setPath_station_index(Integer path_station_index) {
        this.path_station_index = path_station_index;
    }

    public Integer getPath_station_type() {
        return path_station_type;
    }

    public void setPath_station_type(Integer path_station_type) {
        this.path_station_type = path_station_type;
    }

    public String getO_station_name() {
        return o_station_name;
    }

    public void setO_station_name(String o_station_name) {
        this.o_station_name = o_station_name;
    }

    public String getPath_name() {
        return path_name;
    }

    public void setPath_name(String path_name) {
        this.path_name = path_name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    public Integer getStationNum() {
        return stationNum;
    }

    public void setStationNum(Integer stationNum) {
        this.stationNum = stationNum;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public Integer getRecord_id() {
        return record_id;
    }

    public void setRecord_id(Integer record_id) {
        this.record_id = record_id;
    }


    public String getO_station_code() {
        return o_station_code;
    }

    public void setO_station_code(String o_station_code) {
        this.o_station_code = o_station_code;
    }

    public String getD_station_code() {
        return d_station_code;
    }

    public void setD_station_code(String d_station_code) {
        this.d_station_code = d_station_code;
    }

    public Integer getPath_index() {
        return path_index;
    }

    public void setPath_index(Integer path_index) {
        this.path_index = path_index;
    }

    public String getPath_stations() {
        return path_stations;
    }

    public void setPath_stations(String path_stations) {
        this.path_stations = path_stations;
    }

    public Integer getStation_amount() {
        return station_amount;
    }

    public void setStation_amount(Integer station_amount) {
        this.station_amount = station_amount;
    }

    public Integer getTrans_amount() {
        return trans_amount;
    }

    public void setTrans_amount(Integer trans_amount) {
        this.trans_amount = trans_amount;
    }

    public Integer getPath_distance() {
        return path_distance;
    }

    public void setPath_distance(Integer path_distance) {
        this.path_distance = path_distance;
    }

    public Integer getTicket_price() {
        return ticket_price;
    }

    public void setTicket_price(Integer ticket_price) {
        this.ticket_price = ticket_price;
    }

    public Integer getTotal_time() {
        return total_time;
    }

    public void setTotal_time(Integer total_time) {
        this.total_time = total_time;
    }


    public boolean isInfluence() {
        return Influence;
    }

    public void setInfluence(boolean influence) {
        Influence = influence;
    }

    public Map<String, Double> getLinesLoadRate() {
        return linesLoadRate;
    }

    public void setLinesLoadRate(Map<String, Double> linesLoadRate) {
        this.linesLoadRate = linesLoadRate;
    }

    public String getData_version() {
        return data_version;
    }

    public void setData_version(String data_version) {
        this.data_version = data_version;
    }

    public String getUpdate_user() {
        return update_user;
    }

    public void setUpdate_user(String update_user) {
        this.update_user = update_user;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getParam_code() {
        return param_code;
    }

    public void setParam_code(String param_code) {
        this.param_code = param_code;
    }

    public String getParam_name() {
        return param_name;
    }

    public void setParam_name(String param_name) {
        this.param_name = param_name;
    }

    public String getParam_value() {
        return param_value;
    }

    public void setParam_value(String param_value) {
        this.param_value = param_value;
    }

    public String getStation_limit_level() {
        return station_limit_level;
    }

    public void setStation_limit_level(String station_limit_level) {
        this.station_limit_level = station_limit_level;
    }

    public String getEvent_comment() {
        return event_comment;
    }

    public void setEvent_comment(String event_comment) {
        this.event_comment = event_comment;
    }

    public String getControl_type() {
        return control_type;
    }

    public void setControl_type(String control_type) {
        this.control_type = control_type;
    }

    public Integer getMin_delay_time() {
        return min_delay_time;
    }

    public void setMin_delay_time(Integer min_delay_time) {
        this.min_delay_time = min_delay_time;
    }

    public Integer getMax_delay_time() {
        return max_delay_time;
    }

    public void setMax_delay_time(Integer max_delay_time) {
        this.max_delay_time = max_delay_time;
    }

    public boolean isSectionEventInfluence() {
        return sectionEventInfluence;
    }

    public void setSectionEventInfluence(boolean sectionEventInfluence) {
        this.sectionEventInfluence = sectionEventInfluence;
    }


    public Integer getTotalWalkTime() {
        return totalWalkTime;
    }

    public void setTotalWalkTime(Integer totalWalkTime) {
        this.totalWalkTime = totalWalkTime;
    }

    public String getLine_afc_code() {
        return line_afc_code;
    }

    public void setLine_afc_code(String line_afc_code) {
        this.line_afc_code = line_afc_code;
    }

    public String getDirect_station_code() {
        return direct_station_code;
    }

    public void setDirect_station_code(String direct_station_code) {
        this.direct_station_code = direct_station_code;
    }

    public String getTrans_line_afc_code() {
        return trans_line_afc_code;
    }

    public void setTrans_line_afc_code(String trans_line_afc_code) {
        this.trans_line_afc_code = trans_line_afc_code;
    }

    public String getChinesePathName() {
        return chinesePathName;
    }

    public void setChinesePathName(String chinesePathName) {
        this.chinesePathName = chinesePathName;
    }


    public String getLoad_rate_color() {
        return load_rate_color;
    }

    public void setLoad_rate_color(String load_rate_color) {
        this.load_rate_color = load_rate_color;
    }

    public Map<String, Integer> getLinesLoadLevel() {
        return linesLoadLevel;
    }

    public void setLinesLoadLevel(Map<String, Integer> linesLoadLevel) {
        this.linesLoadLevel = linesLoadLevel;
    }

    public boolean isEventPassengerFlowControl() {
        return eventPassengerFlowControl;
    }

    public void setEventPassengerFlowControl(boolean eventPassengerFlowControl) {
        this.eventPassengerFlowControl = eventPassengerFlowControl;
    }

    public boolean isOverrun() {
        return overrun;
    }

    public void setOverrun(boolean overrun) {
        this.overrun = overrun;
    }

    public boolean isDelaysOrInterruptions() {
        return delaysOrInterruptions;
    }

    public void setDelaysOrInterruptions(boolean delaysOrInterruptions) {
        this.delaysOrInterruptions = delaysOrInterruptions;
    }

    public String getOverrunDirectionStation() {
        return overrunDirectionStation;
    }

    public void setOverrunDirectionStation(String overrunDirectionStation) {
        this.overrunDirectionStation = overrunDirectionStation;
    }

    public String getRecoType() {
        return recoType;
    }

    public void setRecoType(String recoType) {
        this.recoType = recoType;
    }

    public Integer getPassFavLevel() {
        return passFavLevel;
    }

    public void setPassFavLevel(Integer passFavLevel) {
        this.passFavLevel = passFavLevel;
    }

    public Integer getUp_down() {
        return up_down;
    }

    public void setUp_down(Integer up_down) {
        this.up_down = up_down;
    }

    public Map<String, String> getLinesColor() {
        return linesColor;
    }

    public void setLinesColor(Map<String, String> linesColor) {
        this.linesColor = linesColor;
    }

    public Map<String, String> getEnLinesColor() {
        return enLinesColor;
    }

    public void setEnLinesColor(Map<String, String> enLinesColor) {
        this.enLinesColor = enLinesColor;
    }

    public String getPathLastTime() {
        return pathLastTime;
    }

    public void setPathLastTime(String pathLastTime) {
        this.pathLastTime = pathLastTime;
    }

    public String getEnPathLastTime() {
        return enPathLastTime;
    }

    public void setEnPathLastTime(String enPathLastTime) {
        this.enPathLastTime = enPathLastTime;
    }

//    public double getMinload() {
//        return minload;
//    }
//
//    public void setMinload(double minload) {
//        this.minload = minload;
//    }


//    public Map<String, String> getLinesLoadColor() {
//        return linesLoadColor;
//    }
//
//    public void setLinesLoadColor(Map<String, String> linesLoadColor) {
//        this.linesLoadColor = linesLoadColor;
//    }
}

