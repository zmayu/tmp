package com.bjjdsy.pojo;

public class ParamSection {
    private String version_code;
    private String line_afc_code;
    private String up_down;
    private String o_station_code;
    private String d_station_code;
    private String direct_station_code;
    private String update_user;
    private String update_time;

    public String getVersion_code() {
        return version_code;
    }

    public void setVersion_code(String version_code) {
        this.version_code = version_code;
    }

    public String getLine_afc_code() {
        return line_afc_code;
    }

    public void setLine_afc_code(String line_afc_code) {
        this.line_afc_code = line_afc_code;
    }

    public String getUp_down() {
        return up_down;
    }

    public void setUp_down(String up_down) {
        this.up_down = up_down;
    }

    public String getO_station_code() {
        return o_station_code;
    }

    public void setO_station_code(String o_station_code) {
        this.o_station_code = o_station_code;
    }

    public String getD_station_code() {
        return d_station_code;
    }

    public void setD_station_code(String d_station_code) {
        this.d_station_code = d_station_code;
    }

    public String getDirect_station_code() {
        return direct_station_code;
    }

    public void setDirect_station_code(String direct_station_code) {
        this.direct_station_code = direct_station_code;
    }

    public String getUpdate_user() {
        return update_user;
    }

    public void setUpdate_user(String update_user) {
        this.update_user = update_user;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }
}
