package com.bjjdsy.pojo;

public class ParamLoadRate {
    private int crowd_level;
    private String crowd_name;
    private String color_code;
    private int down_code;
    private int up_code;

    public int getCrowd_level() {
        return crowd_level;
    }

    public void setCrowd_level(int crowd_level) {
        this.crowd_level = crowd_level;
    }

    public String getCrowd_name() {
        return crowd_name;
    }

    public void setCrowd_name(String crowd_name) {
        this.crowd_name = crowd_name;
    }

    public String getColor_code() {
        return color_code;
    }

    public void setColor_code(String color_code) {
        this.color_code = color_code;
    }

    public int getDown_code() {
        return down_code;
    }

    public void setDown_code(int down_code) {
        this.down_code = down_code;
    }

    public int getUp_code() {
        return up_code;
    }

    public void setUp_code(int up_code) {
        this.up_code = up_code;
    }
}
