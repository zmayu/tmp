package com.bjjdsy.pojo;

public class EventInfluence {
    private boolean eventPassengerFlowControl;
    private boolean overrun;
    private boolean delaysOrInterruptions;
    private String overrunOCode;
    private String overrunDirection;
    private String overrunLineAfcCode;
    private String eventEmergencyOSCode;
    private String eventEmergencyDSCode;
    private String eventEmergencyLineAfcCode;
//    private String eventEmergencyDirection;


    public boolean isEventPassengerFlowControl() {
        return eventPassengerFlowControl;
    }

    public void setEventPassengerFlowControl(boolean eventPassengerFlowControl) {
        this.eventPassengerFlowControl = eventPassengerFlowControl;
    }

    public boolean isOverrun() {
        return overrun;
    }

    public void setOverrun(boolean overrun) {
        this.overrun = overrun;
    }

    public boolean isDelaysOrInterruptions() {
        return delaysOrInterruptions;
    }

    public void setDelaysOrInterruptions(boolean delaysOrInterruptions) {
        this.delaysOrInterruptions = delaysOrInterruptions;
    }

    public String getOverrunOCode() {
        return overrunOCode;
    }

    public void setOverrunOCode(String overrunOCode) {
        this.overrunOCode = overrunOCode;
    }

//    public String getOverrunDCode() {
//        return overrunDCode;
//    }
//
//    public void setOverrunDCode(String overrunDCode) {
//        this.overrunDCode = overrunDCode;
//    }


//    public Integer getEventRecordId() {
//        return eventRecordId;
//    }
//
//    public void setEventRecordId(Integer eventRecordId) {
//        this.eventRecordId = eventRecordId;
//    }

    public String getEventEmergencyOSCode() {
        return eventEmergencyOSCode;
    }

    public void setEventEmergencyOSCode(String eventEmergencyOSCode) {
        this.eventEmergencyOSCode = eventEmergencyOSCode;
    }

    public String getEventEmergencyDSCode() {
        return eventEmergencyDSCode;
    }

    public void setEventEmergencyDSCode(String eventEmergencyDSCode) {
        this.eventEmergencyDSCode = eventEmergencyDSCode;
    }

    public String getEventEmergencyLineAfcCode() {
        return eventEmergencyLineAfcCode;
    }

    public void setEventEmergencyLineAfcCode(String eventEmergencyLineAfcCode) {
        this.eventEmergencyLineAfcCode = eventEmergencyLineAfcCode;
    }

    public String getOverrunDirection() {
        return overrunDirection;
    }

    public void setOverrunDirection(String overrunDirection) {
        this.overrunDirection = overrunDirection;
    }

    public String getOverrunLineAfcCode() {
        return overrunLineAfcCode;
    }

    public void setOverrunLineAfcCode(String overrunLineAfcCode) {
        this.overrunLineAfcCode = overrunLineAfcCode;
    }

//    public String getEventEmergencyDirection() {
//        return eventEmergencyDirection;
//    }
//
//    public void setEventEmergencyDirection(String eventEmergencyDirection) {
//        this.eventEmergencyDirection = eventEmergencyDirection;
//    }
}
