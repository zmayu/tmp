package com.bjjdsy.pojo;

import java.util.Date;

public class EventEmergency {

    private Integer record_id;
    private String event_id;
    private Integer event_source;
    private String line_afc_code;
    private String o_station_code;
    private String d_station_code;
    private String up_down;


    private Date start_time;


    public Integer getRecord_id() {
        return record_id;
    }

    public void setRecord_id(Integer record_id) {
        this.record_id = record_id;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getLine_afc_code() {
        return line_afc_code;
    }

    public void setLine_afc_code(String line_afc_code) {
        this.line_afc_code = line_afc_code;
    }

    public String getO_station_code() {
        return o_station_code;
    }

    public void setO_station_code(String o_station_code) {
        this.o_station_code = o_station_code;
    }

    public String getD_station_code() {
        return d_station_code;
    }

    public void setD_station_code(String d_station_code) {
        this.d_station_code = d_station_code;
    }

    public String getUp_down() {
        return up_down;
    }

    public void setUp_down(String up_down) {
        this.up_down = up_down;
    }

    public Integer getEvent_source() {
        return event_source;
    }

    public void setEvent_source(Integer event_source) {
        this.event_source = event_source;
    }
}
