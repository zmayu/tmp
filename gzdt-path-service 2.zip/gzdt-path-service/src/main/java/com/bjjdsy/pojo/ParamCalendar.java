package com.bjjdsy.pojo;

import java.util.Date;

public class ParamCalendar {
    private Date calendar_day;
    //    private String day_type;
//    private String week_day;
    private Integer day_type;
    private Integer week_day;

    public Date getCalendar_day() {
        return calendar_day;
    }

    public void setCalendar_day(Date calendar_day) {
        this.calendar_day = calendar_day;
    }

//    public String getDay_type() {
//        return day_type;
//    }
//
//    public void setDay_type(String day_type) {
//        this.day_type = day_type;
//    }
//
//    public String getWeek_day() {
//        return week_day;
//    }
//
//    public void setWeek_day(String week_day) {
//        this.week_day = week_day;
//    }

    public Integer getDay_type() {
        return day_type;
    }

    public void setDay_type(Integer day_type) {
        this.day_type = day_type;
    }

    public Integer getWeek_day() {
        return week_day;
    }

    public void setWeek_day(Integer week_day) {
        this.week_day = week_day;
    }
}
