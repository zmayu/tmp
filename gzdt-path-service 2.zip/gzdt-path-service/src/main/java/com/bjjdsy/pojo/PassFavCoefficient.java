package com.bjjdsy.pojo;

public class PassFavCoefficient {
    private String user_id;
    private Double trans_coef;
    private Double trans_count_coef;
    private Double trafic_jam_one;
    private Double trafic_jam_two;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public Double getTrans_coef() {
        return trans_coef;
    }

    public void setTrans_coef(Double trans_coef) {
        this.trans_coef = trans_coef;
    }

    public Double getTrans_count_coef() {
        return trans_count_coef;
    }

    public void setTrans_count_coef(Double trans_count_coef) {
        this.trans_count_coef = trans_count_coef;
    }

    public Double getTrafic_jam_one() {
        return trafic_jam_one;
    }

    public void setTrafic_jam_one(Double trafic_jam_one) {
        this.trafic_jam_one = trafic_jam_one;
    }

    public Double getTrafic_jam_two() {
        return trafic_jam_two;
    }

    public void setTrafic_jam_two(Double trafic_jam_two) {
        this.trafic_jam_two = trafic_jam_two;
    }
}
