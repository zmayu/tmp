package com.bjjdsy.pojo;

public class BaseOdPathLast {
    private String data_version;
    private String o_station_code;
    private String d_station_code;
    private String path_stations;
    private String begin_time;
    private String last_time;

    public String getData_version() {
        return data_version;
    }

    public void setData_version(String data_version) {
        this.data_version = data_version;
    }

    public String getO_station_code() {
        return o_station_code;
    }

    public void setO_station_code(String o_station_code) {
        this.o_station_code = o_station_code;
    }

    public String getD_station_code() {
        return d_station_code;
    }

    public void setD_station_code(String d_station_code) {
        this.d_station_code = d_station_code;
    }

    public String getPath_stations() {
        return path_stations;
    }

    public void setPath_stations(String path_stations) {
        this.path_stations = path_stations;
    }

    public String getBegin_time() {
        return begin_time;
    }

    public void setBegin_time(String begin_time) {
        this.begin_time = begin_time;
    }

    public String getLast_time() {
        return last_time;
    }

    public void setLast_time(String last_time) {
        this.last_time = last_time;
    }
}
