package com.bjjdsy.pojo;

import java.util.List;

public class deleteRepetitiveStationResult {
    private List<String> stationList;
    private String dataVersion;
    private String oStationCode;
    private String OtransStationCode;
    private String dStationCode;
    private String DtransStationCode;

    public List<String> getStationList() {
        return stationList;
    }

    public void setStationList(List<String> stationList) {
        this.stationList = stationList;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }

    public String getoStationCode() {
        return oStationCode;
    }

    public void setoStationCode(String oStationCode) {
        this.oStationCode = oStationCode;
    }

    public String getOtransStationCode() {
        return OtransStationCode;
    }

    public void setOtransStationCode(String otransStationCode) {
        OtransStationCode = otransStationCode;
    }

    public String getdStationCode() {
        return dStationCode;
    }

    public void setdStationCode(String dStationCode) {
        this.dStationCode = dStationCode;
    }

    public String getDtransStationCode() {
        return DtransStationCode;
    }

    public void setDtransStationCode(String dtransStationCode) {
        DtransStationCode = dtransStationCode;
    }
}
