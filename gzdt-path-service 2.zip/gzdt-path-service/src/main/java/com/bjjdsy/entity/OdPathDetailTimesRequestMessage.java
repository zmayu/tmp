package com.bjjdsy.entity;

import com.bjjdsy.message.RequestMessage;

public class OdPathDetailTimesRequestMessage extends RequestMessage {

    OdPathDetailTimesRequestData data;
    public OdPathDetailTimesRequestData getData() {
        return data;
    }

    public void setData(OdPathDetailTimesRequestData data) {
        this.data = data;
    }

}
