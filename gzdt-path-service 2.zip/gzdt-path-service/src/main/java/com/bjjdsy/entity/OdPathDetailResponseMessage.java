package com.bjjdsy.entity;

import com.alibaba.fastjson.JSONObject;
import com.bjjdsy.message.ResponseMessage;

import java.util.List;

public class OdPathDetailResponseMessage extends ResponseMessage {
//    List<OdPathDetailResponseData> data;
//    public List<OdPathDetailResponseData> getData() {
//        return data;
//    }
//
//    public void setData(List<OdPathDetailResponseData> data) {
//        this.data = data;
//    }

    List<JSONObject> data;
    public List<JSONObject> getData() {
        return data;
    }

    public void setData(List<JSONObject> data) {
        this.data = data;
    }
}
