package com.bjjdsy.entity;

import com.bjjdsy.message.ResponseMessage;

public class OdPathTimesResponseMessage  extends ResponseMessage {
    OdPathTimesResponseData data;
    public OdPathTimesResponseData getData() {
        return data;
    }

    public void setData(OdPathTimesResponseData data) {
        this.data = data;
    }
}
