package com.bjjdsy.entity;

import com.bjjdsy.message.RequestMessage;

public class OdPathRequestMessage extends RequestMessage {
    OdPathRequestData data;
    public OdPathRequestData getData() {
        return data;
    }

    public void setData(OdPathRequestData data) {
        this.data = data;
    }

}
