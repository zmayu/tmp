package com.bjjdsy.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class OdPathRequestData {
    private String oStationCode;
    private String dStationCode;
    private String departTime;
    private String userId;

    @XmlAttribute
    public String getoStationCode() {
        return oStationCode;
    }

    public void setoStationCode(String oStationCode) {
        this.oStationCode = oStationCode;
    }

    @XmlAttribute
    public String getdStationCode() {
        return dStationCode;
    }

    public void setdStationCode(String dStationCode) {
        this.dStationCode = dStationCode;
    }

    @XmlAttribute
    public String getDepartTime() {
        return departTime;
    }

    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }

    @XmlAttribute
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
