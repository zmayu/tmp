package com.bjjdsy.entity;

import com.alibaba.fastjson.JSONArray;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class OdPathDetailResponseData {
    private Integer ticketPrice;
    private Integer totalTime;
    private String lastTime;
    private JSONArray stations;
    private Integer stationAmount;
    private Integer transAmount;
    private String allLoadRateColor;


    @XmlAttribute
    public Integer getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(Integer ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    @XmlAttribute
    public Integer getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Integer totalTime) {
        this.totalTime = totalTime;
    }

    @XmlAttribute
    public String getLastTime() {
        return lastTime;
    }

    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }

    @XmlAttribute
    public JSONArray getStations() {
        return stations;
    }

    public void setStations(JSONArray stations) {
        this.stations = stations;
    }

    @XmlAttribute
    public Integer getStationAmount() {
        return stationAmount;
    }

    public void setStationAmount(Integer stationAmount) {
        this.stationAmount = stationAmount;
    }

    @XmlAttribute
    public Integer getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(Integer transAmount) {
        this.transAmount = transAmount;
    }

    @XmlAttribute
    public String getAllLoadRateColor() {
        return allLoadRateColor;
    }

    public void setAllLoadRateColor(String allLoadRateColor) {
        this.allLoadRateColor = allLoadRateColor;
    }
}
