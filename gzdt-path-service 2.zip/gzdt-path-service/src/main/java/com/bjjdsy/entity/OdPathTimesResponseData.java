package com.bjjdsy.entity;

import com.alibaba.fastjson.JSONObject;

import java.util.List;

public class OdPathTimesResponseData {
    private List<JSONObject> totalTimes;

    public List<JSONObject> getTotalTimes() {
        return totalTimes;
    }

    public void setTotalTimes(List<JSONObject> totalTimes) {
        this.totalTimes = totalTimes;
    }

}
