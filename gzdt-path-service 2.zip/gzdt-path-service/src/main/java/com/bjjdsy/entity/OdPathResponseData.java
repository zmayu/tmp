package com.bjjdsy.entity;

import java.util.Map;

public class OdPathResponseData {

    private String oStationCode;
    private String dStationCode;
    private Integer pathIndex;
    private String pathName;
    private Integer stationAmount;
    private Integer transAmount;
    private Integer ticketPrice;
    private Integer totalTime;
    private Double load_rate;
    private String load_rate_color;
    private Map<String, Double> linesLoadRate;
    private Map<String, Integer> linesLoadLevel;
    private Map<String, String> linesColor;
    private Map<String, String> enLinesColor;
    private String recoType;
    private String departTime;
    private Double logitValue;
    private Integer recordId;

//    private String firstValue;
//    private String secondValue;
//    private String thirdValue;

    private Double firstValue;
    private Double secondValue;
    private Double thirdValue;

    private String pathLastTime;
    private String enPathLastTime;

    public String getoStationCode() {
        return oStationCode;
    }

    public void setoStationCode(String oStationCode) {
        this.oStationCode = oStationCode;
    }

    public String getdStationCode() {
        return dStationCode;
    }

    public void setdStationCode(String dStationCode) {
        this.dStationCode = dStationCode;
    }

    public Integer getPathIndex() {
        return pathIndex;
    }

    public void setPathIndex(Integer pathIndex) {
        this.pathIndex = pathIndex;
    }

    public String getPathName() {
        return pathName;
    }

    public void setPathName(String pathName) {
        this.pathName = pathName;
    }

    public Integer getStationAmount() {
        return stationAmount;
    }

    public void setStationAmount(Integer stationAmount) {
        this.stationAmount = stationAmount;
    }

    public Integer getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(Integer transAmount) {
        this.transAmount = transAmount;
    }

    public Integer getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(Integer ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public Integer getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Integer totalTime) {
        this.totalTime = totalTime;
    }


    public Double getLoad_rate() {
        return load_rate;
    }

    public void setLoad_rate(Double load_rate) {
        this.load_rate = load_rate;
    }

    public Map<String, Double> getLinesLoadRate() {
        return linesLoadRate;
    }

    public void setLinesLoadRate(Map<String, Double> linesLoadRate) {
        this.linesLoadRate = linesLoadRate;
    }

    public String getRecoType() {
        return recoType;
    }

    public void setRecoType(String recoType) {
        this.recoType = recoType;
    }


    public String getDepartTime() {
        return departTime;
    }

    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }


    public Double getLogitValue() {
        return logitValue;
    }

    public void setLogitValue(Double logitValue) {
        this.logitValue = logitValue;
    }

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public String getLoad_rate_color() {
        return load_rate_color;
    }

    public void setLoad_rate_color(String load_rate_color) {
        this.load_rate_color = load_rate_color;
    }


    public Map<String, Integer> getLinesLoadLevel() {
        return linesLoadLevel;
    }

    public void setLinesLoadLevel(Map<String, Integer> linesLoadLevel) {
        this.linesLoadLevel = linesLoadLevel;
    }

    public Double getFirstValue() {
        return firstValue;
    }

    public void setFirstValue(Double firstValue) {
        this.firstValue = firstValue;
    }

    public Double getSecondValue() {
        return secondValue;
    }

    public void setSecondValue(Double secondValue) {
        this.secondValue = secondValue;
    }

    public Double getThirdValue() {
        return thirdValue;
    }

    public void setThirdValue(Double thirdValue) {
        this.thirdValue = thirdValue;
    }

    public Map<String, String> getLinesColor() {
        return linesColor;
    }

    public void setLinesColor(Map<String, String> linesColor) {
        this.linesColor = linesColor;
    }

    public Map<String, String> getEnLinesColor() {
        return enLinesColor;
    }

    public void setEnLinesColor(Map<String, String> enLinesColor) {
        this.enLinesColor = enLinesColor;
    }

    public String getPathLastTime() {
        return pathLastTime;
    }

    public void setPathLastTime(String pathLastTime) {
        this.pathLastTime = pathLastTime;
    }

    public String getEnPathLastTime() {
        return enPathLastTime;
    }

    public void setEnPathLastTime(String enPathLastTime) {
        this.enPathLastTime = enPathLastTime;
    }


//    public String getFirstValue() {
//        return firstValue;
//    }
//
//    public void setFirstValue(String firstValue) {
//        this.firstValue = firstValue;
//    }
//
//    public String getSecondValue() {
//        return secondValue;
//    }
//
//    public void setSecondValue(String secondValue) {
//        this.secondValue = secondValue;
//    }
//
//    public String getThirdValue() {
//        return thirdValue;
//    }
//
//    public void setThirdValue(String thirdValue) {
//        this.thirdValue = thirdValue;
//    }
}

