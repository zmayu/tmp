package com.bjjdsy.entity;

import com.alibaba.fastjson.JSONObject;
import com.bjjdsy.message.ResponseMessage;

import java.util.List;

public class OdPathResponseMessage  extends ResponseMessage {
//    List<OdPathResponseData> data;
//
//    public List<OdPathResponseData> getData() {
//        return data;
//    }
//
//    public void setData(List<OdPathResponseData> data) {
//        this.data = data;
//    }

    List<JSONObject> data;
    public List<JSONObject> getData() {
        return data;
    }

    public void setData(List<JSONObject> data) {
        this.data = data;
    }


}
