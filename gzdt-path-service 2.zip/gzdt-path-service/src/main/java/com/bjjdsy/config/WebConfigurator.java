package com.bjjdsy.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.yaoyun.anyonedev.security.app.ca.CAAppAuthListener;
import com.yaoyun.anyonedev.security.sso.SSOFilter;

@Configuration
public class WebConfigurator {

    @Value("${app_key}")
    private String appKey;

    @Value("${app_auth_server}")
    private String appAuthServer;

    @Value("${user_auth_server}")
    private String userAuthServer;

    @Value("${app_secret}")
    private String appSecret;

    @Value("${app_cert}")
    private String appCert;

    @Value("${app_cert_password}")
    private String appCertPassword;

    @Value("${paas_cert}")
    private String paasCert;

    @Value("${user_auth_login_url}")
    private String userAuthLoginUrl;

    @Value("${ignore_filter_urls}")
    private String ignoreFilterUrls;



    @Bean
    public FilterRegistrationBean<SSOFilter> ssoFilterRegister() {
        FilterRegistrationBean<SSOFilter> registration = new FilterRegistrationBean<SSOFilter>();
        registration.setFilter(new SSOFilter());
        registration.addInitParameter("app_key", appKey);
        registration.addInitParameter("app_auth_server", appAuthServer);
        registration.addInitParameter("user_auth_server", userAuthServer);
        registration.addInitParameter("app_secret", appSecret);
        registration.addInitParameter("app_cert", appCert);
        registration.addInitParameter("app_cert_password", appCertPassword);
        registration.addInitParameter("paas_cert", paasCert);
        registration.addInitParameter("user_auth_login_url", userAuthLoginUrl);
        registration.addInitParameter("ignore_filter_urls", ignoreFilterUrls);

        registration.addUrlPatterns("/*");
        registration.setName(SSOFilter.class.getSimpleName());
        registration.setOrder(FilterRegistrationBean.HIGHEST_PRECEDENCE);
        return registration;
    }

    @Bean
    public ServletListenerRegistrationBean<CAAppAuthListener> appAuthListenerRegister() {
        CAAppAuthListener listener = new CAAppAuthListener();
        ServletListenerRegistrationBean<CAAppAuthListener> registration = new ServletListenerRegistrationBean<CAAppAuthListener>();
        System.setProperty("app_key", appKey);
        System.setProperty("app_auth_server", appAuthServer);
        System.setProperty("user_auth_server", userAuthServer);
        System.setProperty("app_secret", appSecret);
        System.setProperty("app_cert", appCert);
        System.setProperty("app_cert_password", appCertPassword);
        System.setProperty("paas_cert", paasCert);
        System.setProperty("user_auth_login_url", userAuthLoginUrl);
        registration.setListener(listener);
        registration.setEnabled(true);
        return registration;
    }

}
