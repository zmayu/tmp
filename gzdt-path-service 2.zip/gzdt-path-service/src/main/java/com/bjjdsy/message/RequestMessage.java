package com.bjjdsy.message;

public class RequestMessage {

	private String appid;
	private String access_token;
	private String partnerid;
	private String timestamp;
	private String version;
	private String signtype;
	private String sign;
	private String encrydata;
	private String encrytype;
	private String encrykey;
	private String clientip;
	private String deviceid;
	private String devicetype;
	private String devicemodel;
	private String appver;

	public String getAppid() {
		return appid;
	}
	public void setAppid(String appid) {
		this.appid = appid;
	}
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getPartnerid() {
		return partnerid;
	}
	public void setPartnerid(String partnerid) {
		this.partnerid = partnerid;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getSigntype() {
		return signtype;
	}
	public void setSigntype(String signtype) {
		this.signtype = signtype;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getEncrydata() {
		return encrydata;
	}
	public void setEncrydata(String encrydata) {
		this.encrydata = encrydata;
	}
	public String getEncrytype() {
		return encrytype;
	}
	public void setEncrytype(String encrytype) {
		this.encrytype = encrytype;
	}
	public String getEncrykey() {
		return encrykey;
	}
	public void setEncrykey(String encrykey) {
		this.encrykey = encrykey;
	}
	public String getClientip() {
		return clientip;
	}
	public void setClientip(String clientip) {
		this.clientip = clientip;
	}
	public String getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}
	public String getDevicetype() {
		return devicetype;
	}
	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}
	public String getDevicemodel() {
		return devicemodel;
	}
	public void setDevicemodel(String devicemodel) {
		this.devicemodel = devicemodel;
	}
	public String getAppver() {
		return appver;
	}
	public void setAppver(String appver) {
		this.appver = appver;
	}



}
