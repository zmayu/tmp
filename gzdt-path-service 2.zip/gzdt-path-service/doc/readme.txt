curl 127.0.0.1:8136/gzdt-path-service/gzdtapp/odpath -X POST -H 'Content-Type: application/json' -d '{"data":{"oStationCode":"101","dStationCode":"102","userId":"2","departTime":"20200908073530"}}'


-H 'Content-Type: application/json' -d '{"key1":"value1", "key2":"value2"}'